<?php
//include("check_session.php");
include("../connection.php");
include("check_session.php");

$bcid=$_SESSION['lid'];
 if(isset($_POST['submit']))
 {

$name=$_POST['name'];
//echo $name;
$phone=$_POST['phone'];
//echo $phone;
$email=$_POST['email'];
//echo $email;

$product=$_POST['product'];
//echo $product;
$city=$_POST['place'];
//echo $city;
$country=$_POST['district'];
//echo $country;
$address=$_POST['address'];
//echo $address;
$zipcode=$_POST['zipcode'];
//echo $zipcode;
$nme =$_FILES['picture']['name'];
////echo $nme;
$temp_name =$_FILES['picture']['tmp_name'];
move_uploaded_file($temp_name,'upload/'.$nme);



$sel="select proname from product1 where proname='$product' ";
$objj=new db();
$login=$objj->execute($sel);
//echo $login; error due to string
$strr=mysqli_fetch_array($login);
echo $strr[0];
//echo "success";
$loo=$strr[0];

$sql="Insert into book(name,email,address,city,zipcode,phone,district,picture,proname,login_id,status) values('$name','$email','$address','$city','$zipcode','$phone','$country','$nme','$loo','$bcid',1)";
$objjj=new db();
$objjj->execute($sql);
if($objjj)
  {
 ?>
 <script>
  alert("Booking Sucessfull");
  window.location="book.php";
</script>
<?php
  }
else
{
	?>
	<script>
  alert("Booking not Sucessfull");
  window.location="book.php";
  </script>
   <?php
}

}

// header("location:book.php");
?>