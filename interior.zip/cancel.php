<?php
include("check_session.php");
//session_start();
$id=$_GET['id'];
//echo $id;
include("../connection.php");
$upd="update book set status=0 where book_id=$id";
$obj=new db();
$obj->execute($upd);
if($obj)
  {
 ?>
 <script>
  alert("Booking cancelled Sucessfull");
  window.location="viewbook.php";
</script>
<?php
  }
else
{
	?>
	<script>
  alert("Booking not cancelled Sucessfull");
  window.location="viewbook.php";
  </script>
   <?php
}

  //header("location:viewbook.php");
?>
