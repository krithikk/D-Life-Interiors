	<?php
  include("../connection.php");
  include("check_session.php");
//$sel1="SELECT products.picture, product1.produid, products.product FROM products INNER JOIN product1 ON products.product_id=product1.product_id ";
//$sel="SELECT products.picture, product1.producid, products.product FROM products INNER JOIN product1 ON product1.product_id=products.product_id WHERE product1.status='1' && products.status='1'";

?>
	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Interior</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">							
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body>	
			  <header id="header" id="home">
		  		<div class="header-top">
		  			<div class="container">
				  		<div class="row">
				  			<div class="col-lg-6 col-sm-6 col-4 header-top-left no-padding">
				  								  
				  			</div>
				  			<div class="col-lg-6 col-sm-6 col-8 header-top-right no-padding">
				  				<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
									<li><a href="#"><i class="fa fa-behance"></i></a></li>
				  				</ul>			
				  			</div>
				  		</div>			  					
		  			</div>
				</div>
			    <div class="container main-menu">
			    	<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo">
				        <a href="userhome.php"><img src="img/logo.png" alt="" title="" /></a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="userhome.php">Home</a></li>
				          <li><a href="about.php">About</a></li>
				          <li><a href="services.php">Services</a></li>
				         
						  <li class="menu-has-children"><a href="#">Products & categories</a>
				            <ul>
			              		<li><a href="projects.php">View products</a></li>		
				                <li><a href="viewbook.php">View Booking</a></li>
						       </ul>  
							<li class="menu-has-children"><a href="notify.php">Order Status</a>      
				          <li class="menu-has-children"><a href="careerr.php">Career</a>
						  <li class="menu-has-children"><a href="#">Account</a>
				            <ul>
			              		<li><a href="profile.php">Profile</a></li>		
				                <li><a href="changepass.php">Change Password</a> </li>
						       </ul>  
				            
				             <li><a href="contact.php">Contact</a></li> 
				          
								<li class="last-grid"><a href="logout.php">Logout</a></li>  
				           
				          </li>					          					          		          
				          
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header><!-- #header -->

			<!-- start banner Area -->
			<section class="banner-area relative" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
								
							<p class="text-white link-nav"><a href="userhome.php">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="projects.php"> Products</a></p>
						
						
						</div>	
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

			<!-- Start gallery Area -->
			<section class="gallery-area section-gap">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="col-md-12 pb-40 header-text text-center">
							<h1 class="pb-10">Our Products</h1>
							
						</div>
					</div>	
					
					<div class="row">
    <div class="col-lg-6 col-md-6">
    <div class="col-lg-6 col-md-6">
         <div class="pull-right">
            
								  <select id="cat" name="cat" style=" outline:#666666;padding: 10px 10px 10px 10px;font-size: 14px;color: black;display: block;width:20%;"  required="" onchange="return dist()" required>
                    <option>--search by category--</option>
                    <?php
					include("dbconnect.php");
                    $con=mysqli_connect("localhost","root","","dlife_inter");
					$_session["unm"]=$username;
					$sql="SELECT * FROM category";
                    $result=mysqli_query($con,$sql);
                    while($row=mysqli_fetch_array($result))
                    {
                        $id=$row['category_id'];
                        $name=$row['categoryname'];
                        ?>
                        
                        <option value='<?php echo $id ?>'><?php echo $name ?></option>;
                        <?php
                    }
                    ?>
                    </select>
		
		<button class="buttons button3">Search here...</button>
		</div>
		</form></center>
		</center>
		
					
					 <?php
		if(isset($_GET['cat']))
		{
				$sql="SELECT * FROM products where category_id='".$_GET['cat']."'		";	
		}
		else
		{
		$sql="SELECT PR.*,L.* FROM products PR,login L where L.login_id=PR.login_id and L.status='1'";

		}
		
		$res=mysqli_query($con,$sql);
		$rowcount=mysqli_num_rows($res);
		if(!$rowcount)
		{
			echo 'No Result Found';
		}
		else{
		while($row=mysqli_fetch_array($res))
		{
		$pimage=$row['picture'];
		//$pname=$row['product'];
		//$price=$row['price'];
		
		?>
		
		
		<div style="display:inline-block;background:black;">
		
		
		
					<div class="card">
                    <img src="../Admin/upload/<?php echo $pimage ?>" width="75" height="150" style="width:75%">
					</div>
					<!--<ul >
						    <li>Name:<?php echo $pname ?></li>
						    <li>Price:<?php echo $price ?></li>
						
						</ul>-->
                  <!-- <h1>Tailored Jeans</h1>
                   <p class="price">$19.99</p>
				   
                   <p><a href="know.php?id=<?php echo $row['product_id'];?>"><center><button class="button">View more..</button></center></a></p>-->
				    <form action="amado/shop.php" method="POST">
				   <input type ="hidden" name="id" value="<?php echo $row['product_id']; ?>" />
				   <input type="submit" value="View more" class="button">
                   </div>
				   <?php
							}
							}
							?>
					
				</div>
				<!-- //banner slider-->
			</div>
		</div>
	</div>
						
								
						
						
					</div>
				
			</section>
			<!-- End gallery Area -->
				
							

			<!-- start footer Area 	
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-5 col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h6>About Us</h6>
								<p>
									If you own an Iphone, you’ve probably already worked out how much fun it is to use it to watch movies-it has that.
								</p>
								<p class="footer-text"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This website is made  <i class="fa fa-heart-o" aria-hidden="true"></i> by Krithi K Krishna</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. </p>								
							</div>
						</div>
						<div class="col-lg-5  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h6>Newsletter</h6>
								<p>Stay update with our latest</p>
								<div class="" id="mc_embed_signup">
									<form target="_blank" novalidate="true" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="form-inline">
										<input class="form-control" name="EMAIL" placeholder="Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address'" required="" type="email">
			                            	<button class="click-btn btn btn-default"><i class="lnr lnr-arrow-right" aria-hidden="true"></i></button>
			                            	<div style="position: absolute; left: -5000px;">
												<input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
											</div>
										<div class="info"></div>
									</form>
								</div>
							</div>
						</div>						
						<div class="col-lg-2 col-md-6 col-sm-6 social-widget">
							<div class="single-footer-widget">
								<h6>Follow Us</h6>
								<p>Let us be social</p>
								<div class="footer-social d-flex align-items-center">
									<a href="#"><i class="fa fa-facebook"></i></a>
									<a href="#"><i class="fa fa-twitter"></i></a>
									<a href="#"><i class="fa fa-dribbble"></i></a>
									<a href="#"><i class="fa fa-behance"></i></a>
								</div>
							</div>
						</div>							
					</div>
				</div>
			</footer>	
			<!-- End footer Area -->	

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
			<script src="js/owl.carousel.min.js"></script>						
			<script src="js/jquery.nice-select.min.js"></script>							
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
		</body>
	</html>