<?php
include("check_session.php");
//session_start();
$id=$_GET['id'];
//echo $id;
include("../connection.php");
$upd="update orderconf set status=0 where confid=$id";
$obj=new db();
$obj->execute($upd);
if($obj)
  {
 ?>
 <script>
  alert("order cancelled Sucessfully");
  window.location="notify.php";
</script>
<?php
  }
else
{
	?>
	<script>
  alert("order not cancelled Sucessfully");
  window.location="notify.php";
  </script>
   <?php
}

  //header("location:viewbook.php");
?>
