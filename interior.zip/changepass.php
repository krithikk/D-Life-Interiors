	
  <?php
  include("../connection.php");
  include("check_session.php");
  
$sel="select email from login where login_id=$lid";
$obj=new db();
$login=$obj->execute($sel);

?>
	
	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>Interior</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">							
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body class="blog-page">	
			  <header id="header" id="home">
		  		<div class="header-top">
		  			<div class="container">
				  		<div class="row">
				  			<div class="col-lg-6 col-sm-6 col-4 header-top-left no-padding">
				  								  
				  			</div>
				  			<div class="col-lg-6 col-sm-6 col-8 header-top-right no-padding">
				  				<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
									<li><a href="#"><i class="fa fa-behance"></i></a></li>
				  				</ul>			
				  			</div>
				  		</div>			  					
		  			</div>
				</div>
			    <div class="container main-menu">
			    	<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo">
				        <a href="userhome.php"><img src="img/logo.png" alt="" title="" /></a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="userhome.php">Home</a></li>
				          <li><a href="about.php">About</a></li>
				          <li><a href="services.php">Services</a></li>
				         
						  <li class="menu-has-children"><a href="#">Products & categories</a>
				            <ul>
			              		<li><a href="projects.php">View products</a></li>		
				                <li><a href="viewbook.php">View Booking</a></li>
						       </ul>  
							  <li class="menu-has-children"><a href="notify.php">Order Status</a>    
				          <li class="menu-has-children"><a href="careerr.php">Career</a>
						  <li class="menu-has-children"><a href="#">Account</a>
				            <ul>
			              		<li><a href="profile.php">Profile</a></li>		
				                <li><a href="changepass.php">Change Password</a> </li>
						       </ul>  
				            
				             <li><a href="contact.php">Contact</a></li> 
				          
								<li class="last-grid"><a href="logout.php">Logout</a></li>  
				           
				          </li>					          					          		          
				          
				        </ul>
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header><!-- #header -->
			  

			<!-- start banner Area -->
			<section class="banner-area relative cat-widget2" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content blog-header-content col-lg-12">
								
							
		<div class="csslider infinity" id="slider1">
					
					<ul class="banner_slide_bg">
						<li>
							<center><center>
<div align="center">
<div class="container">
<div class="col-sm-9" style="margin-left:5px"> 
<div class="panel-heading" style="background-color:grey width:10px">
	<h1>Change Password</h1></div><br>
	<br>

 <form name="myForm"  method="post"  autocomplete="off"

 
   onsubmit="return validateForm()" method="post">
   
   
  
  <br> 
	
	<div class="row">
      <div class="col-25">
        <label for="entername">CURRENT EMAIL:</label>
      </div>
      <div class="col-75">
	  <?php
							if(mysqli_num_rows($login)>0)
							{
								
							while($row=mysqli_fetch_array($login))
							{
								?>
				
								<input type="email" value="<?php echo $row['email'];?>" name="email1" id="email1" placeholder="Email id.." required>
        
			
								<!--<a href="#about" class="btn btn-banner my-sm-3 mr-2">Read More</a>-->
							<?php
							}
							}
							?>
       
      </div>
    </div>
<br>    

<div class="row">
      <div class="col-25">
        <label for="dob"> NEW PASSWORD:</label>
      </div>
	  <div class="col-75">
 <input type="password" id="password" name="newpassword"  id="newpassword"  placeholder="New password..." pattern="{6,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
        
	   </div>
      </div>
	 
    <br>
	
<div class="row">
      <div class="col-25">
        <label for="dob"> CONFIRM 
		 PASSWORD:</label>
      </div>
	  
      <div class="col-75">
 <input type="password" id="password" name="confirmnewpassword" id="confirmnewpassword"  placeholder="Confirm Password.." pattern="{6,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
      
	   </div>
      </div>
	
<center>	
 <div class="row" align="center">
 
     <div class="col-25">
  <center><center><input type="submit" name="submit"  value="UPDATE"></center> </center><br>
</center>
 </div>
 </div>
 </div>
 </div>
  </center>
   </center>
						</li>
						
					</ul>
					
				</div>
						</li>
						
					</ul>
					
				</div>				</li>
						
					</ul>
					
				</div>
						</div>	
					</div>
				</div>
			</section>
			<head>
<style>


input[type=text],[type=date],[type=button],[type=email],[type=password] ,select, textarea {
    width: 60%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 5px;
    resize: vertical;
}

body {
  margin: 0;
  padding: 0;
  background:violet;
  font-size: 16px;
  color: #222;
  font-family: 'Roboto', sans-serif;
  font-weight: 300;
}

.centered {
    position: absolute;
    top: 40%;
    left: 50%;
    transform: translate(-50%, -50%);
    }
.text{
	width:105%;
	height:50%;
	margin-left:200px;
	margin-top:100px;
	 column-count: 2;
      }
.footer {
  position:fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   height:8%;
   background-color: black;
   margin-top:100px;
}
ul{
margin:0px;
padding:0px;
list-style:none;
}
}
ul li a{
text-decoration:none;
}
ul li a:hover{
background-color-green;

}
ul li ul li
{
display:none;l
}
ul li:hover ul li{
display:block;
}

h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:white;
}

input[type=submit] {
    
    background-color: pink;
	width: 100%;
    padding: 20px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left=200px;
    float: center;
}

input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}


.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}
a{
	color: white;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit],input[type=button] {
        width: 100%;
        margin-top: 0;
    }
}
 </style>
</head>

</form>  
	
   
<?php
include "conn.php";
//session_start();
/*include "connection.php";
if(isset($_POST['submit']))
 {
        $email = $_POST['email'];
	
        
        $newpassword =$_POST['newpassword'];
	
        $confirmnewpassword = $_POST['confirmnewpassword'
        $result = mysql_query (con,"SELECT password FROM org1 WHERE  email='$email'");
		  
        if(!$result)
        {
        echo "The username you entered does not exist";
        }
        else if($password!= mysql_result($result, 0))
        {
        echo "You entered an incorrect password";
        }
        if($newpassword=$confirmnewpassword)
        $sql=mysql_query(" UPDATE org1 SET password='$newpassword' where email='$email'");
        if($sql)
        {
        echo "Congratulations You have successfully changed your password";
        }
       else
        {
       echo "Passwords do not match";
	  
       }
 }
      ?>*/
	  
	 
if(isset($_POST['submit']))
{
$uname=	$_POST["email1"];
$new=$_POST["newpassword"];
$conf=$_POST["confirmnewpassword"];
$re= mysqli_query($con,"select * from login  where email='$uname'");


if(mysqli_num_rows($re)>0)
{
	
	if ($new==$conf)
	{ 
	mysqli_query($con,"update login set password='$new' where email='$uname'");
	?>
		<script>
		alert("successfully updated")
		</script>
		<?php
	}
	else
	{
		?>
		<script>
		alert("Password MisMatch")
		</script>
	
<?php
	}
}
else
{
	
	?>
    
    <script>
	alert("Password Does not exists")
	</script>    
    <?php }
}?>

 
			<!-- End banner Area -->				  

	
			
			<!-- start footer Area 	
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-5 col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h6>About Us</h6>
								<p>
									If you own an Iphone, you’ve probably already worked out how much fun it is to use it to watch movies-it has that.
								</p>
								<p class="footer-text"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. 
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. </p>								
							</div>
						</div>
						<div class="col-lg-5  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h6>Newsletter</h6>
								<p>Stay update with our latest</p>
								<div class="" id="mc_embed_signup">
									<form target="_blank" novalidate="true" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="form-inline">
										<input class="form-control" name="EMAIL" placeholder="Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address'" required="" type="email">
			                            	<button class="click-btn btn btn-default"><i class="lnr lnr-arrow-right" aria-hidden="true"></i></button>
			                            	<div style="position: absolute; left: -5000px;">
												<input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
											</div>
										<div class="info"></div>
									</form>
								</div>
							</div>
						</div>						
						<div class="col-lg-2 col-md-6 col-sm-6 social-widget">
							<div class="single-footer-widget">
								<h6>Follow Us</h6>
								<p>Let us be social</p>
								<div class="footer-social d-flex align-items-center">
									<a href="#"><i class="fa fa-facebook"></i></a>
									<a href="#"><i class="fa fa-twitter"></i></a>
									<a href="#"><i class="fa fa-dribbble"></i></a>
									<a href="#"><i class="fa fa-behance"></i></a>
								</div>
							</div>
						</div>							
					</div>
				</div>
			</footer>	
			<!-- End footer Area -->	

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
			<script src="js/owl.carousel.min.js"></script>						
			<script src="js/jquery.nice-select.min.js"></script>							
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
		</body>
	</html>