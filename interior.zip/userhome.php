	<?php
  include("../connection.php");
  include("check_session.php");
//session_start();
//$lid=$_SESSION['lid'];
$sel="select email from login where login_id=$lid";
$obj=new db();
$login=$obj->execute($sel);
  
  //echo $lid;
?>
	
	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>D'LIFE HOME INTERIORS</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">							
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body>	
			  <header id="header" id="home">
		  		<div class="header-top">
		  			<div class="container">
				  		<div class="row">
				  			<div class="col-lg-6 col-sm-6 col-4 header-top-left no-padding">
				  				<?php
							if(mysqli_num_rows($login)>0)
							{
								
							while($row=mysqli_fetch_array($login))
							{
								?>
				
								<h6 class="b-w3ltxt" style="color:white">Welcome&nbsp<?php echo $row['email'];?> </h6>
			
								<!--<a href="#about" class="btn btn-banner my-sm-3 mr-2">Read More</a>-->
							<?php
							}
							}
							?>	
							
				  			</div>
							
				  			<div class="col-lg-6 col-sm-6 col-8 header-top-right no-padding">
							<div class="container">
  <form class="form-inline" method="post" action="prosearch.php">
    <input type="text" name="rollno" class="form-control" placeholder="Search products.." required>
    <input type="submit" class="btn btn-success" value="search" name="submit" id="submit">
  </form>
</div>
				  				<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
									<li><a href="#"><i class="fa fa-behance"></i></a></li>
				  				</ul>			
				  			</div>
				  		</div>			  					
		  			</div>
				</div>
			    <div class="container main-menu">
			    	<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo">
				        <a href="userhome.php"><img src="img/logo.png" alt="" title="" /></a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="userhome.php">Home</a></li>
				          <li><a href="about.php">About</a></li>
				          <li><a href="services.php">Services</a></li>
				         
						  <li class="menu-has-children"><a href="#">Products & categories</a>
				            <ul>
			              		<li><a href="projects.php">View products</a></li>		
				                <li><a href="viewbook.php">View Booking</a></li>
						       </ul>  
							<li class="menu-has-children"><a href="notify.php">Order Status</a>   
				          <li class="menu-has-children"><a href="careerr.php">Career</a>
						  <li class="menu-has-children"><a href="#">Account</a>
				            <ul>
			              		<li><a href="profile.php">Profile</a></li>		
				                <li><a href="changepass.php">Change Password</a> </li>
						       </ul>  
				            
				             <li><a href="contact.php">Contact</a></li> 
				          
								<li class="last-grid"><a href="logout.php">Logout</a></li>  
				           
				          </li>					          					          		          
				          
				        </ul>
						
					
					
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header><!-- #header -->

			<!-- start banner Area -->
			<section class="banner-area relative" id="home">
				<div class="overlay overlay-bg"></div>
				<div class="container">
					<div class="row fullscreen d-flex justify-content-center align-items-center">
						<div class="banner-content col-lg-9 col-md-12 justify-content-center ">
							<h1>
								Precise concept design <br>
								for stylish living			
							</h1>
							
							<a href="estimate.php" class="primary-btn header-btn text-uppercase mt-10">Get a quote</a>
						</div>											
					</div>
				</div>
			</section>
			

			<!-- Start gallery Area -->
			<section class="gallery-area pb-120">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="col-md-12 pb-40 header-text text-center">
							<h1 class="pb-10">Our Recent Works may impress you</h1>
							<p>
								Who are in extremely love with eco friendly system.
							</p>
						</div>
					</div>							
					<div class="row">
						<div class="col-lg-8">
							<div class="single-gallery">
								<div class="content">
								    <a href="#" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto" src="img/g1.jpg" alt="">
								      <div class="content-details fadeIn-bottom">
								        <h3 class="content-title mx-auto">Lavendar ambient interior</h3>
								        
								      </div>
								    </a>
								</div>
							</div>
						</div>
						<div class="col-lg-4">
							<div class="single-gallery">
								<div class="content">
								    <a href="#" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto" src="img/g2.jpg" alt="">
								      <div class="content-details fadeIn-bottom">
								        <h3 class="content-title mx-auto">Ambient interior</h3>
								    
								      </div>
								    </a>
								</div>
							</div>
						</div>	
						<div class="col-lg-4">
							<div class="single-gallery">
								<div class="content">
								    <a href="#" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto" src="img/g3.jpg" alt="">
								      <div class="content-details fadeIn-bottom">
								        <h3 class="content-title mx-auto">Ambient interior</h3>
								        
								      </div>
								    </a>
								</div>
							</div>
						</div>
						<div class="col-lg-8">
							<div class="single-gallery">
								<div class="content">
								    <a href="#" target="_blank">
								      <div class="content-overlay"></div>
								  		 <img class="content-image img-fluid d-block mx-auto" src="img/g4.jpg" alt="">
								      <div class="content-details fadeIn-bottom">
								        <h3 class="content-title mx-auto">Lavendar ambient interior</h3>
								        
								      </div>
								    </a>
								</div>
							</div>
						</div>												
					</div>
				</div>	
			</section>
			<!-- End gallery Area -->
				
			<!-- Start feature Area -->
			<section class="feature-area section-gap">
				<div class="container">
					<div class="row d-flex justify-content-center">
						<div class="col-md-12 pb-40 header-text text-center">
							<h1 class="pb-10 text-white">Some Features that Made us Unique</h1>
							<p class="text-white">
								Who are in extremely love with eco friendly system.
							</p>
						</div>
					</div>							
					<div class="row">
						<div class="col-lg-4 col-md-6">
							<div class="single-feature">
								<a href="#" class="title d-flex flex-row align-items-center">
									<span class="lnr lnr-user"></span>
									<h4>Expert Technicians</h4>
								</a>
								
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="single-feature">
								<a href="#" class="title d-flex flex-row align-items-center">
									<span class="lnr lnr-license"></span>
									<h4>Professional Service</h4>
								</a>
								
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="single-feature">
								<a href="#" class="title d-flex flex-row align-items-center">
									<span class="lnr lnr-phone"></span>
									<h4>Great Support</h4>
								</a>
								
							</div>
						</div>						
						<div class="col-lg-4 col-md-6">
							<div class="single-feature">
								<a href="#" class="title d-flex flex-row align-items-center">
									<span class="lnr lnr-rocket"></span>
									<h4>Technical Skills</h4>
								</a>
								
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="single-feature">
								<a href="#" class="title d-flex flex-row align-items-center">
									<span class="lnr lnr-diamond"></span>
									<h4>Highly Recomended</h4>
								</a>
								
							</div>
						</div>
						<div class="col-lg-4 col-md-6">
							<div class="single-feature">
								<a href="#" class="title d-flex flex-row align-items-center">
									<span class="lnr lnr-bubble"></span>
									<h4>Positive Reviews</h4>
								</a>
								
							</div>
						</div>	

					</div>
				</div>	
			</section>
			<!-- End feature Area -->		
		
		    	

			<!-- Start callto-action Area -->
			<section class="callto-action-area pt-120">
				<div class="container">
					<div class="row justify-content-center">
						<div class="callto-action-wrap col-lg-12 relative section-gap">
							<div class="content">
								<h1>
									Looking for a <br>
									quality and affordable interior design?
								</h1>
								<p class="mx-auto">
									inappropriate behavior is often laughed off as “boys will be boys,” women face higher conduct standards especially in the workplace.
								</p>
								<a href="#" class="primary-btn text-uppercase">Request quote now</a>			
							</div>							
						</div>
					</div>
				</div>	
			</section>
			<!-- End callto-action Area -->
								
			

					

			<!-- start footer Area 
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-5 col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h6>About Us</h6>
								<p>
									If you own an Iphone, you’ve probably already worked out how much fun it is to use it to watch movies-it has that.
								</p>
								<p class="footer-text"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This website is made <i class="fa fa-heart-o" aria-hidden="true"></i> by Krithi K Krishna</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0.</p>								
							</div>
						</div>
						<div class="col-lg-5  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h6>Newsletter</h6>
								<p>Stay update with our latest</p>
								<div class="" id="mc_embed_signup">
									<form target="_blank" novalidate="true" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="form-inline">
										<input class="form-control" name="EMAIL" placeholder="Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address'" required="" type="email">
			                            	<button class="click-btn btn btn-default"><i class="lnr lnr-arrow-right" aria-hidden="true"></i></button>
			                            	<div style="position: absolute; left: -5000px;">
												<input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
											</div>
										<div class="info"></div>
									</form>
								</div>
							</div>
						</div>						
						<div class="col-lg-2 col-md-6 col-sm-6 social-widget">
							<div class="single-footer-widget">
								<h6>Follow Us</h6>
								<p>Let us be social</p>
								<div class="footer-social d-flex align-items-center">
									<a href="#"><i class="fa fa-facebook"></i></a>
									<a href="#"><i class="fa fa-twitter"></i></a>
									<a href="#"><i class="fa fa-dribbble"></i></a>
									<a href="#"><i class="fa fa-behance"></i></a>
								</div>
							</div>
						</div>							
					</div>
				</div>
			</footer>	
			<!-- End footer Area -->	

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
			<script src="js/owl.carousel.min.js"></script>						
			<script src="js/jquery.nice-select.min.js"></script>							
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
		</body>
	</html>