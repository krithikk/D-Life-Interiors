<?php
//include("check_session.php");
include("../connection.php");

 if(isset($_POST['submit']))
 {

//$name =$_FILES['file']['name'];
//echo $name;
//$temp_name =$_FILES['file']['tmp_name'];
//move_uploaded_file($temp_name,'upload/'.$name);
 
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$comment=$_POST['comments'];
//$cpass=$_POST['cpwd'];
//echo $namee;


$sql="Insert into contact(name,email,phone,comments,status) values('$name','$email','$phone','$comment',1)";
$obj=new db();
$obj->execute($sql);

if($obj)
  {
 ?>
 <script>
  alert("Message sent Sucessfully");
  window.location="contact.php";
</script>
<?php
  }
else
{
	?>
	<script>
  alert("Message not sent Sucessfully");
  window.location="contact.php";
  </script>
   <?php
}

    


}


 //header("location:addstaff.php");
?>

 