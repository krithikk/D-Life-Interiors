<?php
// include("../connection.php");
  
	$db = mysqli_connect('localhost', 'root', '', 'dlife_inter');


include("check_session.php");
$bcid=$_SESSION['lid'];

//$se="SELECT a.event_id,a.cat_id,a.event_name,b.date,b.time,b.stage_id,b.schedule_id FROM events a JOIN event_schedule b ON a.event_id=b.event_id and a.status!='0' ";
//$se="SELECT a.book_id,a.login_id,a.email,a.proname,b.packid,b.proname,b.price,b.adprice FROM book a JOIN packtbl b ON a.name=b.name and a.status='1'";
 $se="SELECT * from orderconf WHERE login_id='$bcid'";
 $re=mysqli_query($db,$se);
 require('tcpdf_min/tcpdf.php');
 $pdf = new TCPDF();
 $pdf->AddPage();
 //$pdf->SetFont('Arial','B',16);

$data='<table><tr><th>Bill Details</th></tr>';
$pdf->Cell(0,10,'DLife Home Interiors',0,1,'C');
$pdf->Cell(190,10,'Bill Details',0,1,'C');
//$pdf->Cell(45,20,'Name_staff:',1,0,'C');
$pdf->Cell(45,20,'Name_Product :',1,0,'C');
$pdf->Cell(45,20,'Exp_Amount:',1,0,'C');
$pdf->Cell(45,20,'Full_Amount:',1,0,'C');
$pdf->Cell(45,20,'Advance_Amount',1,0,'C');

 while($row=mysqli_fetch_array($re))
              {             
                            
                            
                            $s1= $row['confid'];
                     $s="select proname from orderconf where confid='$s1'";
                            $p=mysqli_query($db,$s);
                             $ro=mysqli_fetch_array($p,MYSQLI_ASSOC);
      
                            $event= $ro['proname'];
                             

                            $c1= $row['confid'];

$c="select exp from orderconf where confid='$c1'";
$p=mysqli_query($db,$c);
 $ro=mysqli_fetch_array($p,MYSQLI_ASSOC);
 $s2=$ro['exp'];

                            $date=$row['amount'];
                            $time=$row['advance'];
                            

                            $pdf->Ln(20);

                            $pdf->Cell(45,20,$event, 1, 0, 'C');
                            
                           
                            
							 $pdf->Cell(45,20,$s2, 1, 0, 'C');
                            
                            $pdf->Cell(45,20,$date , 1, 0, 'C');
                            $pdf->Cell(45,20,$time, 1, 0, 'C');
                          

              }
              $pdf->Output();          
?>

