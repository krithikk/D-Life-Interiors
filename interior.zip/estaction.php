<?php
//include("check_session.php");
include("../connection.php");
 if(isset($_POST['submit']))
 {

$name=$_POST['name'];
//echo $name;
$email=$_POST['email'];
$phone=$_POST['phone'];
$location=$_POST['place'];
$comment=$_POST['comments'];
$namee =$_FILES['picture']['name'];
//echo $namee;
$temp_name =$_FILES['picture']['tmp_name'];
move_uploaded_file($temp_name,'upload/'.$namee);


$sql="Insert into estimate(name,email,phone,location,comments,picture,status) values('$name','$email','$phone','$location','$comment','$namee','1')";
$obj=new db();
$obj->execute($sql);
if($obj)
  {
 ?>
 <script>
  alert("Estimate Requested Sucessfully");
  window.location="estimate.php";
</script>
<?php
  }
else
{
	?>
	<script>
  alert("Estimate not sent Sucessfully");
  window.location="estimate.php";
  </script>
   <?php
}

    

}

 //header("location:estimate.php");
?>