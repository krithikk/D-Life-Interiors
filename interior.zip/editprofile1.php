<?php
include('../connection.php');
include("check_session.php");
	 
$id=$_SESSION['lid'];
//echo $id;
if($id>0)
{
$name=$_POST['name'];
//echo $name;
$phone=$_POST['phone'];
//echo $phone;
$email=$_POST['email'];
//echo $email;

$sql="update register set name='$name',phone='$phone',email='$email' where login_id='$id'";
$obj=new db();
$obj->execute($sql);
 }
 header("location:profile.php");
?>