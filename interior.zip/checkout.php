
<?php
include("../connection.php");
include("check_session.php");
$bcid=$_SESSION['lid'];
//$gt=$_GET['gt'];
if(isset($_POST['submit']))
{
	$name=$_POST["name"];
	//$lname=$_POST["lname"];
	//$country=$_POST["country"];
	//$address=$_POST["address"];
	//$city=$_POST["city"];
	//$zip=$_POST["zip"];
	$phone=$_POST["phone"];
	$email=$_POST["email"];
	$amount=$_POST["amount"];
	//$gto=$_POST["gto"];  
	$sql="INSERT INTO  payment(name,phone,email,amount,login_id)values('$name','$phone','$email','$amount','$bcid')";
	//$sql="Insert into book(name,email,address,city,zipcode,phone,district,picture,proname,login_id,status) values('$name','$email','$address','$city','$zipcode','$phone','$country','$nme','$loo','$bcid',1)";
     $obj=new db();
     $obj->execute($sql);
	 if($obj)
	 {
	?>
			<script type="text/javascript">
				alert("Pay with Paytm");
				window.location.href="Paytm_Web_Sample_Kit_PHP-master/PaytmKit/TxnTest.php";
			</script>
		<?php
	}
}
?>
<!DOCTYPE html>
	<html>
	<a href="userhome.php">Home</a>
	
	<head>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    

	<style>
	    .booking-div {
            padding: 15px;
            box-shadow: inset 0 0 0 1px;
            border: 5px solid #fbfbfc;
            -webkit-border-radius: 5px;
            -moz-border-radius: 5px;
            border-radius: 5px;
            margin-bottom: 30px;
            background-color: #fff;
            width: 350px;
            margin: 0% 10%;
           }

         .b-fields. b-f-div label {
	                 background: #dbdbdb;
					 font-size: 12px;
					 margin-top: 0;
					 position: absolute;
					 padding: 10px;
					 border-radius: 5px 0 0 5px;
					 color: #787878;
	                 width: 60px;
					 text-align: center;
	
                  }
.input{
	width:100%;
	height:35px;
	border-radius:4px;
	border:1px solid #528ff0;
	padding-left:5px;
      }

</style>
			
		
						<body style="background-image:-webkit-linear-gradient(90deg,#528ff0,#528ff096,#528ff02b);">
						<center>
						<?php
					if($bcid>0)
{
	
	$obj=new db();
	$select="select * from register where login_id='$bcid'";
	$data=$obj->execute($select);
	$row=mysqli_fetch_array($data);
	?>
						<div style="margin:8% 0 0">
						<h1>payment</h1>
						</div>
						<div class="booking-div">
						<div class="booking-fields">
						<form  method="POST">
						<table style="width:100%; font-family:sans-serif; text-align:left; color:#345daf;">
						<tbody>
						<tr>
						<th>Customer Name</th>
						</tr>
						<tr>
						<td><input type="text" name="name" id="name" value="<?php echo $row['name'];?>" required></td>
						</tr>
						<tr>
						<th>Customer Email</th>
						</tr>
						<tr>
						<td><input type="email" name="email" id="email" value="<?php echo $row['email'];?>" required></td>
						</tr>
						<tr>
						<th>Customer Phone</th>
						</tr>
						<tr>
						<td><input type="text" name="phone" id="phone" value="<?php echo $row['phone'];?>" required></td>
						</tr>
						<tr>
						<th>Amount</th>
						</tr>
						<tr>
						<td><input type="text" name="amount" id="amount" value="" required></td>
						</tr>
						<tr>
						<br>
						<td><input type="submit" class="btn btn-success"  name="submit" value="pay now" id="submit" style="background-color:blue"></td>
						</tr>
						
						</tbody>
						</table>
						</form>
						<div>
						</div>
						</center>
					</div>
				</div>	
			<?php 
}	
?>

			
		</body>
	</html>