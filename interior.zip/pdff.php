<?php


	$db = mysqli_connect('localhost', 'root', '', 'dlife_inter');
$bcid=$_GET['id'];



//$se="SELECT a.event_id,a.cat_id,a.event_name,b.date,b.time,b.stage_id,b.schedule_id FROM events a JOIN event_schedule b ON a.event_id=b.event_id and a.status!='0' ";
//$se="SELECT a.book_id,a.login_id,a.email,a.proname,b.packid,b.proname,b.price,b.adprice FROM book a JOIN packtbl b ON a.name=b.name and a.status='1'";
$se="SELECT packtbl.packid,packtbl.proname,orderconf.confid,orderconf.proname,packtbl.price,packtbl.adprice FROM orderconf INNER JOIN packtbl ON orderconf.proname=packtbl.proname where orderconf.status='1' && orderconf.login_id='$bcid'";
	 
 $re=mysqli_query($db,$se);
 require('tcpdf_min/tcpdf.php');
 $pdf = new TCPDF();
 $pdf->AddPage();
 //$pdf->SetFont('Arial','B',16);

$data='<table><tr><th>Bill Details</th></tr>';
$pdf->Cell(0,10,'DLife Home Interiors',0,1,'C');
$pdf->Cell(190,10,'Bill Details',0,1,'C');
//$pdf->Cell(45,20,'Email_Cust:',1,0,'C');
$pdf->Cell(45,20,'Name_Product :',1,0,'C');
$pdf->Cell(45,20,'Full_Amount:',1,0,'C');
$pdf->Cell(45,20,'Advance_Amount',1,0,'C');

 while($row=mysqli_fetch_array($re))
              {             
                            
                            
                            $s1= $row['confid'];
                     $s="select proname from confid where confid='$s1'";
                            $p=mysqli_query($db,$s);
                             $ro=mysqli_fetch_array($p,MYSQLI_ASSOC);
      
                            $event= $ro['email'];
                             

                            $c1= $row['packid'];

$c="select price from packtbl where packid='$c1'";
$p=mysqli_query($db,$c);
 $ro=mysqli_fetch_array($p,MYSQLI_ASSOC);
 $s2=$ro['price'];

                            
                            $time=$row['adprice'];
                            

                            $pdf->Ln(20);

                            $pdf->Cell(45,20,$event, 1, 0, 'C');
                            
                           
                            
							 $pdf->Cell(45,20,$s2, 1, 0, 'C');
                            
                           
                            $pdf->Cell(45,20,$time, 1, 0, 'C');
                          

              }
              $pdf->Output();          
?>

