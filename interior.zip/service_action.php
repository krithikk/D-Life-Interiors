<?php
//include("check_session.php");
include("../connection.php");
 if(isset($_POST['submit']))
 {

//$name =$_FILES['file']['name'];
//echo $name;
//$temp_name =$_FILES['file']['tmp_name'];
//move_uploaded_file($temp_name,'upload/'.$name);
 
$name=$_POST['name'];
$serv=$_POST['servicetype'];
$phone=$_POST['phone'];
//$user=$_POST['user'];
$email=$_POST['email'];
$pro=$_POST['product'];
//$cpass=$_POST['cpwd'];
//echo $namee;
$namee =$_FILES['picture']['name'];
//echo $namee;
$temp_name =$_FILES['picture']['tmp_name'];
move_uploaded_file($temp_name,'upload/'.$namee);




$sql="Insert into servicetbl(name,service,phone,email,productname,picture,status) values('$name','$serv','$phone','$email','$pro','$namee',0)";
$obj=new db();
$obj->execute($sql);

if($obj)
  {
 ?>
 <script>
  alert("Service requested Sucessfull");
  window.location="services.php";
</script>
<?php
  }
else
{
	?>
	<script>
  alert("Service not requested  Sucessfull");
  window.location="services.php";
  </script>
   <?php
}
 }


 //header("location:services.php");
?>

 