<?php
//include("check_session.php");
include("../connection.php");
 if(isset($_POST['submit']))
 {

$name=$_POST['name'];
//echo $name;
$email=$_POST['email'];
//echo $email;
$phone=$_POST['phone'];
//echo $phone;
$place=$_POST['place'];
//echo $place;
$job=$_POST['job'];
//echo $job;
$code=$_POST['captcha_code'];
//echo $code;
$namee =$_FILES['picture']['name'];
//echo $namee;
$temp_name =$_FILES['picture']['tmp_name'];
move_uploaded_file($temp_name,'upload/'.$namee);


$sql="Insert into jobuser(name,email,phone,place,job,code,picture,status) values('$name','$email','$phone','$place','$job','$code','$namee',0)";
$obj=new db();
$obj->execute($sql);
if($obj)
  {
 ?>
 <script>
  alert("job requested Sucessfull");
  window.location="careerr.php";
</script>
<?php
  }
else
{
	?>
	<script>
  alert("job not requested  Sucessfull");
  window.location="careerr.php";
  </script>
   <?php
}



    }


// header("location:careerr.php");
?>