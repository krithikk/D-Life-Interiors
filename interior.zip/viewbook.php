	<?php
  include("../connection.php");
  include("check_session.php");
$bcid=$_SESSION['lid'];
$sel="SELECT * FROM book where status='1' && login_id=$bcid ";
	$obj=new db();
	$select=$obj->execute($sel);
?>
	
	<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link rel="shortcut icon" href="img/fav.png">
		<!-- Author Meta -->
		<meta name="author" content="colorlib">
		<!-- Meta Description -->
		<meta name="description" content="">
		<!-- Meta Keyword -->
		<meta name="keywords" content="">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>D'LIFE HOME INTERIORS</title>

		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">							
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/owl.carousel.css">
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body class="blog-page">	
			  <header id="header" id="home">
		  		<div class="header-top">
		  			<div class="container">
				  		<div class="row">
				  			<div class="col-lg-6 col-sm-6 col-4 header-top-left no-padding">
				  								  
				  			</div>
				  			<div class="col-lg-6 col-sm-6 col-8 header-top-right no-padding">
				  				<ul>
									<li><a href="#"><i class="fa fa-facebook"></i></a></li>
									<li><a href="#"><i class="fa fa-twitter"></i></a></li>
									<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
									<li><a href="#"><i class="fa fa-behance"></i></a></li>
				  				</ul>			
				  			</div>
				  		</div>			  					
		  			</div>
				</div>
			    <div class="container main-menu">
			    	<div class="row align-items-center justify-content-between d-flex">
				      <div id="logo">
				        <a href="userhome.php"><img src="img/logo.png" alt="" title="" /></a>
				      </div>
				      <nav id="nav-menu-container">
				        <ul class="nav-menu">
				          <li class="menu-active"><a href="userhome.php">Home</a></li>
				          <li><a href="about.php">About</a></li>
				          <li><a href="services.php">Services</a></li>
				         
						  <li class="menu-has-children"><a href="#">Products & categories</a>
				            <ul>
			              		<li><a href="projects.php">View products</a></li>		
				                <li><a href="viewbook.php">View Booking</a></li>
						       </ul>  
							  <li class="menu-has-children"><a href="notify.php">Order Status</a>    
				          <li class="menu-has-children"><a href="careerr.php">Career</a>
						  <li class="menu-has-children"><a href="#">Account</a>
				            <ul>
			              		<li><a href="profile.php">Profile</a></li>		
				                <li><a href="changepass.php">Change Password</a> </li>
						       </ul>  
				            
				             <li><a href="contact.php">Contact</a></li> 
				          
								<li class="last-grid"><a href="logout.php">Logout</a></li>  
				           
				          </li>					          					          		          
				          
				        </ul>
						
				      </nav><!-- #nav-menu-container -->		    		
			    	</div>
			    </div>
			  </header><!-- #header -->
			  

			<!-- start banner Area -->
			
			<section class="banner-area relative cat-widget2" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content blog-header-content col-lg-12">
								
							
		<div class="csslider infinity" id="slider1">
					
					<ul class="banner_slide_bg">
						<li>
							<div class="col-sm-9" style="margin-left:10px"> 
<div class="panel-heading" style="background-color:grey">
	<h1>View Booking</h1></div><br>

<br>
<br>
<br>

	
	<form  class="form-horizontal" name="myForm" method="post" action="#" style="background-color:white">
	
		<?php
		
	if(mysqli_num_rows($select)>0)
   {
?>


<?php


echo "<table border='1' class='table table-bordered table-hover table-striped' style='font-size:10px'>
<tr>
<th text='blue'>Name</th><th>Email</th><th>Address</th><th>City</th><th>ZipCode</th><th>Phone</th><th>District</th>
<th>Action</th>


</tr>";
while($row=mysqli_fetch_array($select))
{
echo "<tr>";

echo "<td>" . $row['name'] . "</td>";
echo "<td>" . $row['email'] . "</td>";
echo "<td>" . $row['address'] . "</td>";
echo "<td>" . $row['city']. "</td>";
echo "<td>" . $row['zipcode']. "</td>";
echo "<td>" . $row['phone']. "</td>";
echo "<td>" . $row['district']. "</td>";

?>

<td>
<!--<a href="cancel.php" value="<input type="submit" class="btn btn-success"  name="submit" id="submit" style="background-color:#3c78d8">Cancel</a>-->
 <a href="cancel.php?id= <?php echo $row['book_id']; ?>" onclick="return confirm_alert(this);" value="<input type="submit" class="btn btn-success"  name="submit" id="submit" style="background-color:maroon">Cancel</a>
 </td>

<?php

}
}
echo "</table>"; 
?>
	
</form>

</div>
</div>
						</li>
						
					</ul>
					
				</div>
						</div>	
					</div>
				</div>
			</section>
			<!-- End banner Area -->				  

	
			
			<!-- start footer Area 	
			<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-5 col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h6>About Us</h6>
								<p>
									If you own an Iphone, you’ve probably already worked out how much fun it is to use it to watch movies-it has that.
								</p>
								<p class="footer-text"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. 
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. </p>								
							</div>
						</div>
						<div class="col-lg-5  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h6>Newsletter</h6>
								<p>Stay update with our latest</p>
								<div class="" id="mc_embed_signup">
									<form target="_blank" novalidate="true" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="form-inline">
										<input class="form-control" name="EMAIL" placeholder="Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address'" required="" type="email">
			                            	<button class="click-btn btn btn-default"><i class="lnr lnr-arrow-right" aria-hidden="true"></i></button>
			                            	<div style="position: absolute; left: -5000px;">
												<input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
											</div>
										<div class="info"></div>
									</form>
								</div>
							</div>
						</div>						
						<div class="col-lg-2 col-md-6 col-sm-6 social-widget">
							<div class="single-footer-widget">
								<h6>Follow Us</h6>
								<p>Let us be social</p>
								<div class="footer-social d-flex align-items-center">
									<a href="#"><i class="fa fa-facebook"></i></a>
									<a href="#"><i class="fa fa-twitter"></i></a>
									<a href="#"><i class="fa fa-dribbble"></i></a>
									<a href="#"><i class="fa fa-behance"></i></a>
								</div>
							</div>
						</div>							
					</div>
				</div>
			</footer>	
			<!-- End footer Area -->	

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
			<script src="js/owl.carousel.min.js"></script>						
			<script src="js/jquery.nice-select.min.js"></script>							
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
		</body>
	</html>