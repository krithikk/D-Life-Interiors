<?php
include('../connection.php');
include("check_session.php");
$sel="select email from login where login_id=$lid";
$obj=new db();
$login=$obj->execute($sel);

?>
<!DOCTYPE html>
<html>
<head>

<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
.contain
{
	width:100%;
	lenght:100%;
}
</style>
<title>Team home</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Royal Furnish Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<link href='//fonts.googleapis.com/css?family=Kanit:400,100,100italic,200,200italic,300,300italic,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/numscroller-1.0.js"></script>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<script src="js/responsiveslides.min.js"></script>
</head>
<body>
<div class="banner w3ls">
	<div class="container">
		<div class="header-nav wow fadeInUp animated" data-wow-delay=".5s">
			<nav class="navbar navbar-default">
				
				<div class="navbar-header logo">
								<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
								<!--<h1>
									<a class="navbar-brand" href="index.php"><img src="images/logo.png" alt=" " /></a>
								</h1>-->
								
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
				
				
				
			<style>



/* Sub Menu */

.tkvsoft ul {
	position: absolute;
	top: 40px;
	left: 0;

	opacity: 0;
	
	background: #fff;

}

.tkvsoft li:hover > ul { opacity: 1; }

.tkvsoft ul li {
	height: 0;
	overflow: hidden;
	padding: 0;
	

}

.tkvsoft li:hover > ul li {
	height: 36px;
	overflow: visible;
	padding: 0;
	
}

.tkvsoft ul li a {
	width: 200px;
	margin: 0;
padding:30px;
	border: none;
	
}

.tkvsoft ul li:last-child a { border: none; }

/* Icons */
</style>	

				                <nav class="cl-effect-1">
									<ul class="nav navbar-nav tkvsoft">
										<li><a class="active" href="staff.php">Home</a></li>
										
										<li><a href="work.php">Work Assigned</a></li>
										<li><a href="workreq.php">work request Status</a>
										
										<li><a href="leave.php">Leave Status</a>
										
										
										<li><a href="apply.php">Apply Leave</a></li>
										
										<li><a href="profile.php">Profile</a></li>
										<li><a href="changepasswords.php">  Change Password</a></li>
										<li><a href="logout.php">Logout</a></li>
										<!--<li><a>My Account</a>
										<ul>
										<li><a href="../edit_pro_supplier/index.php">Profile</a></li>
										<li><a href="../change password/index.php"> Password</a></li>
										<li><a href="logout.php">Logout</a></li>
		                                </ul>-->
										
										
									</ul>
								</nav>
				</div>
				<!-- /navbar-collapse -->
			</nav>
		</div>
		<div class="banner" id="home">
	<div class="layer">
		<div class="container">
			<div class="banner-text-w3pvt">
				<!-- banner slider-->
				<div class="csslider infinity" id="slider1">
					<input type="radio" name="slides" checked="checked" id="slides_1" />
					<input type="radio" name="slides" id="slides_2" />
					<input type="radio" name="slides" id="slides_3" />
					<ul class="banner_slide_bg">
						<li>
							<center><center>
<div align="center">
<div class="container">

 <form name="myform" id="myform"  action=""  autocomplete="off" onsubmit="return validateForm()" method="post">
   
   
  
  <br> 
	
	<div class="row">
      <div class="col-25">
        <label for="entername">CURRENT EMAIL:</label>
      </div>
      <div class="col-75">
	  <?php
							if(mysqli_num_rows($login)>0)
							{
								
							while($row=mysqli_fetch_array($login))
							{
								?>
				
								<input type="email" value="<?php echo $row['email'];?>" name="email1" id="email1" placeholder="Email id.." required>
        
			
								<!--<a href="#about" class="btn btn-banner my-sm-3 mr-2">Read More</a>-->
							<?php
							}
							}
							?>
       
      </div>
    </div>
<br>    
<div class="row">
      <div class="col-25">
        <label for="dob"> NEW PASSWORD:</label>
      </div>
	  <div class="col-75">
 <input type="password" id="newpassword" name="newpassword"    placeholder="New password..." pattern="{6,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
  <!--<span id="pwd_error_message" style="color:red"></span> -->     
	   </div>
      </div>
	 
    <br>
	
<div class="row">
      <div class="col-25">
        <label for="dob"> CONFIRM 
		 PASSWORD:</label>
      </div>
	  
      <div class="col-75">
 <input type="password"  name="confirmnewpassword" id="confirmnewpassword"  placeholder="Confirm Password.." pattern="{6,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
  <!-- <span id="cpwd_error_message" style="color:red"></span>   -->
	   </div>
      </div>
	
<center>	
 <div class="row" align="center">
 
     <div class="col-25">
  <center><center><input type="submit" name="submit" id="submit"  value="UPDATE"></center> </center><br>
</center>
 </div>
 </div>
 </div>
 </div>
  </center>
   </center>
						</li>
						
					</ul>
					
				</div>
				<!-- //banner slider-->
			</div>
		</div>
	</div>
</div>


<head>
<style>


input[type=text],[type=date],[type=button],[type=email],[type=password] ,select, textarea {
    width: 60%;
    padding: 12px;
    border: 2px solid #ccc;
    border-radius: 5px;
    resize: vertical;
}

body {
  margin: 0;
  padding: 0;
  background:violet;
  font-size: 16px;
  color: #222;
  font-family: 'Roboto', sans-serif;
  font-weight: 300;
}

.centered {
    position: absolute;
    top: 40%;
    left: 50%;
    transform: translate(-50%, -50%);
    }
.text{
	width:105%;
	height:50%;
	margin-left:200px;
	margin-top:100px;
	 column-count: 2;
      }
.footer {
  position:fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   height:8%;
   background-color: black;
   margin-top:100px;
}
ul{
margin:0px;
padding:0px;
list-style:none;
}
}
ul li a{
text-decoration:none;
}
ul li a:hover{
background-color-green;

}
ul li ul li
{
display:none;l
}
ul li:hover ul li{
display:block;
}

h1
{
margin-left:120px;
color:white;
}
label {
    padding:12px,20px;
    display: inline-block;
color:white;
}

input[type=submit] {
    
    background-color: pink;
	width: 100%;
    padding: 20px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left=200px;
    float: center;
}

input[type=submit]:hover {
    background-color: #45a049;
}
input[type=button]:hover {
    background-color: #45a049;
}


.col-25 {
    float: left;
    width: 25%;
    margin-top: 6px;
}

.col-75 {
    float: left;
    width: 75%;
    margin-top: 6px;
}
a{
	color: white;
}

/* Clear floats after the columns */
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .col-25, .col-75, input[type=submit],input[type=button] {
        width: 100%;
        margin-top: 0;
    }
}
		
		<div class="clearfix"></div>
		<div class="banner-info wow bounceInDown" data-wow-duration="1.5s" data-wow-delay="0s">
			<div  id="top" class="callbacks_container">
				<ul class="rslides" id="slider3">
					<li>
						<div class="col-md-5 ban-left">
							<img src="images/p10.jpg" alt=" "/>
						</div>
						<div class="col-md-7 ban-right">
							<h3>We Design Develop and Deliver Using 100% Natural Materials</h3>
							
						</div>
						<div class="clearfix"></div>
					</li>
					<li>
						<div class="col-md-5 ban-left">
							<img src="images/p3.jpg" alt=" "/>
						</div>
						<div class="col-md-7 ban-right">
							<h3>We Have Best Design Experts With Good Ideas In Designing</h3>
							
							
						</div>
						<div class="clearfix"></div>
					</li>
				</ul>
			</div>
			<div class="clearfix"></div>
			<script>
						// You can also use "$(window).load(function() {"
						$(function () {
						 // Slideshow 4
						$("#slider3").responsiveSlides({
							auto: true,
							pager: false,
							nav: true,
							speed: 500,
							namespace: "callbacks",
							before: function () {
						$('.events').append("<li>before event fired.</li>");
						},
						after: function () {
							$('.events').append("<li>after event fired.</li>");
							}
							});
						});
			</script>

		</div>
	</div>
</div>
<!-- //banner -->
<!-- about -->


		

	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //smooth scrolling -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>


<?php
include "conn.php";	 
if(isset($_POST['submit']))
{
$uname=	$_POST["email1"];
$new=$_POST["newpassword"];
$conf=$_POST["confirmnewpassword"];

$re= mysqli_query($con,"select * from login  where email='$uname'");


if(mysqli_num_rows($re)>0)
{
	
	if ($new==$conf)
	{ 
	mysqli_query($con,"update login set password='$new' where email='$uname'");
	
	?>
		<script>
		alert("successfully updated")
		</script>
		
		<?php
	}
	else
	{
		?>
		<script>
		alert("Password MisMatch")
		</script>
	
<?php
	}
}
else
{
	
	?>
    
    <script>
	alert("Password Does not exists")
	</script>    
    <?php 
	}
}
?>
