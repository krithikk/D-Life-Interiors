<?php


	


$db = mysqli_connect('localhost', 'root', '', 'dlife_inter');


//$se="SELECT a.event_id,a.cat_id,a.event_name,b.date,b.time,b.stage_id,b.schedule_id FROM events a JOIN event_schedule b ON a.event_id=b.event_id and a.status!='0' ";
//$se="SELECT * FROM book WHERE login_id='$bcid'";
$se="SELECT book.name,login.login_id,book.book_id,book.address,book.city,book.district,book.phone,book.proname FROM book INNER JOIN login ON book.login_id=login.login_id WHERE  book.status='1'";
 $re=mysqli_query($db,$se);
 require('tcpdf_min/tcpdf.php');
 $pdf = new TCPDF();
 $pdf->AddPage();
 //$pdf->SetFont('Arial','B',16);

$data='<table><tr><th>Bill Details</th></tr>';
$pdf->Cell(0,10,'DLife Home Interiors',0,1,'C');
$pdf->Cell(190,10,'Customer Details',0,1,'C');
$pdf->Cell(35,20,'Name:',1,0,'C');
$pdf->Cell(35,20,'Address:',1,0,'C');
$pdf->Cell(25,20,'City:',1,0,'C');
$pdf->Cell(25,20,'Dist:',1,0,'C');
$pdf->Cell(25,20,'Phone:',1,0,'C');
$pdf->Cell(45,20,'Product :',1,0,'C');


 while($row=mysqli_fetch_array($re))
              {             
                            
                            
                            $s1= $row['book_id'];
                     $s="select name from book where book_id='$s1'";
                            $p=mysqli_query($db,$s);
                             $ro=mysqli_fetch_array($p,MYSQLI_ASSOC);
      
                            $event= $ro['name'];
                             

                            $c1= $row['book_id'];

$c="select address from book where book_id='$c1'";
$p=mysqli_query($db,$c);
 $ro=mysqli_fetch_array($p,MYSQLI_ASSOC);
 $s2=$ro['address'];

                            
                            $time=$row['city'];
                              $zip=$row['district'];
                             $phone=$row['phone'];
							   $pro=$row['proname'];
                            $pdf->Ln(20);

                            $pdf->Cell(35,20,$event, 1, 0, 'C');
                            
                           
                            
							 $pdf->Cell(35,20,$s2, 1, 0, 'C');
                            
                           
                            $pdf->Cell(25,20,$time, 1, 0, 'C');
							$pdf->Cell(25,20,$zip , 1, 0, 'C');
							$pdf->Cell(25,20,$phone , 1, 0, 'C');
							$pdf->Cell(45,20,$pro , 1, 0, 'C');
                          

              }
              $pdf->Output();          
?>

