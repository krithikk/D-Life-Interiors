<?php
include("../connection.php");
include("check_session.php");
$bcid=$_SESSION['lid'];
//echo $bcid;
if(isset($_POST['submit']))
 {
	 
$email=$_POST['email'];
$description=$_POST['desc'];  
$dow=$_POST['dow'];
$doww=$_POST['dow2'];
$date=date("Y-m-d");


if($dow >= $date && $doww >= $dow )
{
	
$sql="INSERT INTO pendingtbl(email,dow,doww,Description,login_id,status) VALUES('$email','$dow','$doww','$description','$bcid',0)";
$obj=new db();
$obj->execute($sql);
if($obj)
{
	?>
 <script>
  alert("Request Applied Successfully");
  window.location="pending.php";
</script>
<?php
  }
else
{
	?>
	<script>
  alert("Expired date cannot support");
  window.location="pending.php";
  </script>
   <?php
}

}
}


?>
    