<?php
include('../connection.php');
include("check_session.php");
$bcid=$_SESSION['lid'];
//include("check_session.php");

?>

<!DOCTYPE html>
<html>
<head>
<script src="js/validate.js"> </script>
	
	<script type="text/javascript" language="javascript" src="javascripts/jquery.js"> </script>
	<script type="text/javascript" language="javascript" src="javascripts/new.js"> </script>
<title>Staff home</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Royal Furnish Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<link href='//fonts.googleapis.com/css?family=Kanit:400,100,100italic,200,200italic,300,300italic,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/numscroller-1.0.js"></script>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<script src="js/responsiveslides.min.js"></script>
</head>
<body>
<div class="banner w3ls">
	<div class="container">
		<div class="header-nav wow fadeInUp animated" data-wow-delay=".5s">
			<nav class="navbar navbar-default">
				
				<!--<div class="navbar-header logo">
								<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
								<!--<h1>
									<a class="navbar-brand" href="index.php"><img src="images/logo.png" alt=" " /></a>
								</h1>
								
				</div>-->
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
				
				
				
			<!--<style>



/* Sub Menu */

.tkvsoft ul {
	position: absolute;
	top: 40px;
	left: 0;

	opacity: 0;
	
	background: #fff;

}

.tkvsoft li:hover > ul { opacity: 1; }

.tkvsoft ul li {
	height: 0;
	overflow: hidden;
	padding: 0;
	

}

.tkvsoft li:hover > ul li {
	height: 36px;
	overflow: visible;
	padding: 0;
	
}

.tkvsoft ul li a {
	width: 200px;
	margin: 0;
padding:30px;
	border: none;
	
}

.tkvsoft ul li:last-child a { border: none; }

/* Icons */
</style>	-->
<style>
        .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
        </style>
 



				                <nav class="cl-effect-1">
									<ul class="nav navbar-nav tkvsoft">
										<li><a class="active" href="staff.php">Home</a></li>
										
										<li><a href="work.php">Work Assigned</a></li>
										<li><a href="workreq.php">work request Status</a>
										
										<li><a href="leave.php">Leave Status</a>
										
										
										<li><a href="apply.php">Apply Leave</a></li>
										
										<li><a href="profile.php">Profile</a></li>
										<li><a href="changepasswords.php">  Change Password</a></li>
										<li><a href="logout.php">Logout</a></li>
										<!--<li><a>My Account</a>
										<ul>
										<li><a href="../edit_pro_supplier/index.php">Profile</a></li>
										<li><a href="../change password/index.php"> Password</a></li>
										<li><a href="logout.php">Logout</a></li>
		                                </ul>-->
										
										
									</ul>
								</nav>
				</div>
				<!-- /navbar-collapse -->
			</nav>
		</div>
		<br>
		<br>
		<center>
		<main class="mn-inner">
                <div class="row">
                    
                <div class="col s12 m12 l8">
                        <div class="card">
                            <div class="card-content">
                                <form id="prodad" action="pendaction.php" method="post" name="prodad">
                                    <table>
									<div>
                                        <h2 style="color:white">Work Pending Request</h3>
										<br><br>
                                        <section>
                                            <div class="wizard-content">
                                                <div class="row">
                                                    <div class="col m12">
                                                        <div class="row">
    
<br><br>
 <form action="pendaction.php" name="prodad" method="post" id="prodad">
 <?php
 
if($bcid>0)
{
	
	$obj=new db();
	$select="select email from login where login_id='$bcid'";
	$data=$obj->execute($select);
	$row=mysqli_fetch_array($data);
	?>
	  <br>
	 
	<div class="input-field col m6 s12">
	<label for="name" style="color:white">Email</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<input name="email"  type="email" class="input-lg" style="font-size:18px; width:300px" value="<?php echo $row['email'];?>"  id="email" style="font-size:18px; width:400px" placeholder="Email"  required>
<span id="dow_error_message" style="color:red"></span>
</div>
<br><br>
<br>

<div class="input-field col m6 s12">
<label for="dow" style="color:white">Date Of Work From</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
<input name="dow"  type="date" class="input-lg" style="font-size:18px; width:300px"  id="dow" style="font-size:18px; width:400px" placeholder="From Date"  required>
<span id="dow_error_message" style="color:red"></span>
</div>
<br><br>
<br>

<div class="input-field col m6 s12">
<label for="dow2" style="color:white">Date Of Work To </label>&nbsp &nbsp &nbsp &nbsp   &nbsp  &nbsp &nbsp  &nbsp  &nbsp &nbsp 
<input name="dow2"  type="date" class="input-lg" style="font-size:18px; width:300px"  id="dow2" style="font-size:18px; width:400px" placeholder="To Date"  required>
<span id="dow_error_message" style="color:red"></span>
</div>
<br><br>


<div class="input-field col m12 s12">
<!--<label for="birthdate">Description</label>  -->  

<!--<textarea id="textarea1" name="description" class="materialize-textarea" length="500" required></textarea>-->
<label for="description" style="color:white">DESCRIPTION</label>&nbsp &nbsp &nbsp   
<textarea name="desc" class="input-lg" type="text"  id="desc" style="font-size:18px; width:400px" length="500" placeholder="Description"  required>
</textarea>
<span id="desc_error_message" style="color:red"></span>
</div>
</div>
<br>
<br>
      <button type="submit" value="submit"  name="submit" id="submit" class="btn btn-success" style="font-size:18px">Apply</button>                                             

                                                </div>
                                            </div>
                                        </section>
                                     
                                    
                                        </section>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
		</center>

</table>
		
<?php 
}	
?>
	
	
<!-- //smooth scrolling -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
</body>
</html>
 