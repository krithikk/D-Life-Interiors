<?php
//session_start();
//session_destroy();
session_start();
if(isset($_SESSION['lid'])&& $_SESSION['lid']!="")
{
  $_SESSION['lid']="";
  unset($_SESSION['lid']);
  session_destroy();
  header("location: ../login/login.php");
  
}
else
{
   header("location: ../login/login.php");
}
//header("location:../shop.php");

?>