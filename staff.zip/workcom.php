<?php
include('../connection.php');
include("check_session.php");
	 
$id=$_SESSION['lid'];
//echo $id;
if($id>0)
{

$sql="update jobasstbl set status='1' where login_id='$id'";
$obj=new db();
$obj->execute($sql);

$sql="update worktbl set status='0' where login_id='$id'";
$obj=new db();
$obj->execute($sql);
 }
 header("location:work.php");
?>