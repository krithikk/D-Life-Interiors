<?php
include('../connection.php');
include("check_session.php");
$bcid=$_SESSION['lid'];
$sel="SELECT * FROM tblleaves where status=2 && login_id=$bcid ";
	$obj=new db();
	$select=$obj->execute($sel);
?>
<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
.contain
{
	width:100%;
	lenght:100%;
}
</style>
<title>Team home</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Royal Furnish Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<link href='//fonts.googleapis.com/css?family=Kanit:400,100,100italic,200,200italic,300,300italic,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/numscroller-1.0.js"></script>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<script src="js/responsiveslides.min.js"></script>
</head>
<body>
<div class="banner w3ls">
	<div class="container">
		<div class="header-nav wow fadeInUp animated" data-wow-delay=".5s">
			<nav class="navbar navbar-default">
				
				<!--<div class="navbar-header logo">
								<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
								<!--<h1>
									<a class="navbar-brand" href="index.php"><img src="images/logo.png" alt=" " /></a>
								</h1>
								
				</div>-->
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
				
				
				
			<style>



/* Sub Menu */

.tkvsoft ul {
	position: absolute;
	top: 40px;
	left: 0;

	opacity: 0;
	
	background: #fff;

}

.tkvsoft li:hover > ul { opacity: 1; }

.tkvsoft ul li {
	height: 0;
	overflow: hidden;
	padding: 0;
	

}

.tkvsoft li:hover > ul li {
	height: 36px;
	overflow: visible;
	padding: 0;
	
}

.tkvsoft ul li a {
	width: 200px;
	margin: 0;
padding:30px;
	border: none;
	
}

.tkvsoft ul li:last-child a { border: none; }

/* Icons */
</style>	

				                <nav class="cl-effect-1">
									<ul class="nav navbar-nav tkvsoft">
										<li><a class="active" href="staff.php">Home</a></li>
										
										<li><a href="work.php">Work Assigned</a></li>
										<li><a href="workreq.php">work request Status</a>
										
										<li><a href="leave.php">Leave Status</a>
										
										
										<li><a href="apply.php">Apply Leave</a></li>
										
										<li><a href="profile.php">Profile</a></li>
										<li><a href="changepasswords.php">  Change Password</a></li>
										<li><a href="logout.php">Logout</a></li>
										<!--<li><a>My Account</a>
										<ul>
										<li><a href="../edit_pro_supplier/index.php">Profile</a></li>
										<li><a href="../change password/index.php"> Password</a></li>
										<li><a href="logout.php">Logout</a></li>
		                                </ul>-->
										
										
									</ul>
								</nav>
				</div>
				<!-- /navbar-collapse -->
			</nav>
		</div>
		<div class="col-sm-9" style="margin-left:10px"> 
<div class="panel-heading" style="background-color:#c4e17f">
	<h1>View Leave Status </h1></div><br>





<!--<form action="cataction.php" name="cat" method="post" id="cat">
<input name="category" class="input-lg" type="text"  id="category" style="font-size:18px; width:200px" placeholder="Add_company" autofocus required>
<span id="product_error_message" style="color:red"></span><br><br>

<hr>
 <input type="submit" class="btn btn-success" name="submit" id="submit" style="font-size:18px">
</form>


	</div>	-->
	
	<form  class="form-horizontal " name="myForm" method="post" action="#">
		<?php
		
	if(mysqli_num_rows($select)>0)
   {



echo "<table border='2' class='table table-bordered table-hover table-striped' style='font-size:20px'>
<tr>
<th text='blue'>LeaveType</th><th>Session</th></th><th>Leave Date</th>
<th>Description</th><th>Status</th>

</tr>";
while($row=mysqli_fetch_array($select))
{
echo "<tr>";

echo "<td>" . $row['LeaveType'] . "</td>";
echo "<td>" . $row['session'] . "</td>";
echo "<td>" . $row['FromDate'] . "</td>";
echo "<td>" . $row['Description']. "</td>";


if($row["status"]=="3")
                          {
                            echo '<td style="color : red ">Rejected</td></tr>';
                          }
                          else if($row["status"]=="2")
                          {
                            echo '<td style="color :#69FA24 ">Approved</td></tr>';
						  }


}
}
echo "</table>"; 
?>
		


		

	
	
<!-- //smooth scrolling 
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>-->
</body>
</html>