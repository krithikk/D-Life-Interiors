<?php
include('../connection.php');
include("check_session.php");
$bcid=$_SESSION['lid'];
//include("check_session.php");

?>

<!DOCTYPE html>
<html>
<head>
<!--<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
.contain
{
	width:100%;
	lenght:100%;
}
</style>-->
<title>Staff home</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Royal Furnish Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<link href='//fonts.googleapis.com/css?family=Kanit:400,100,100italic,200,200italic,300,300italic,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/numscroller-1.0.js"></script>
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<script src="js/responsiveslides.min.js"></script>
</head>
<body>
<div class="banner w3ls">
	<div class="container">
		<div class="header-nav wow fadeInUp animated" data-wow-delay=".5s">
			<nav class="navbar navbar-default">
				
				<!--<div class="navbar-header logo">
								<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
									<span class="sr-only">Toggle navigation</span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
								<!--<h1>
									<a class="navbar-brand" href="index.php"><img src="images/logo.png" alt=" " /></a>
								</h1>
								
				</div>-->
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
				
				
				
			<!--<style>



/* Sub Menu */

.tkvsoft ul {
	position: absolute;
	top: 40px;
	left: 0;

	opacity: 0;
	
	background: #fff;

}

.tkvsoft li:hover > ul { opacity: 1; }

.tkvsoft ul li {
	height: 0;
	overflow: hidden;
	padding: 0;
	

}

.tkvsoft li:hover > ul li {
	height: 36px;
	overflow: visible;
	padding: 0;
	
}

.tkvsoft ul li a {
	width: 200px;
	margin: 0;
padding:30px;
	border: none;
	
}

.tkvsoft ul li:last-child a { border: none; }

/* Icons */
</style>	-->
<style>
        .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
        </style>
 



				                <nav class="cl-effect-1">
									<ul class="nav navbar-nav tkvsoft">
										<li><a class="active" href="staff.php">Home</a></li>
										
										<li><a href="work.php">Work Assigned</a></li>
										<li><a href="workreq.php">work request Status</a>
										
										<li><a href="leave.php">Leave Status</a>
										
										
										<li><a href="apply.php">Apply Leave</a></li>
										
										<li><a href="profile.php">Profile</a></li>
										<li><a href="changepasswords.php">  Change Password</a></li>
										<li><a href="logout.php">Logout</a></li>
										<!--<li><a>My Account</a>
										<ul>
										<li><a href="../edit_pro_supplier/index.php">Profile</a></li>
										<li><a href="../change password/index.php"> Password</a></li>
										<li><a href="logout.php">Logout</a></li>
		                                </ul>-->
										
										
									</ul>
								</nav>
				</div>
				<!-- /navbar-collapse -->
			</nav>
		</div>
		 <div class="col-sm-9" style="margin-left:10px"> 
<div class="panel-heading" style="background-color:#c4e17f">
	<h1>Profile</h1></div><br>




<?php
//session_start();
//include("../connection.php");
$Lid=$_SESSION['lid'];
if($Lid>0)
{
	
	$obj=new db();
	$select="select * from staffdetails where login_id='$Lid'";
	$data=$obj->execute($select);
	$row=mysqli_fetch_array($data);
	?>
	

	<!--<tr>
	<td colspan="2"><div align="center">
	<a href="editprofile1.php?" id=<?php echo $row['login_id'];?>">Edit</a>
	</div>
	</td>
	</tr>-->

<form action="editprofile.php" name="staff" method="post" id="staff">
<label for="name" style="color:white">Name</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<input name="name" value="<?php echo $row['name'];?>" class="input-lg" type="text"  id="name" style="font-size:18px; width:400px" placeholder="Full Name" autofocus required>
<!--<span id="product_error_message" style="color:red"></span><br><br>-->
<br>
<br>
<label for="dob" style="color:white">DOB</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<input name="dob" value="<?php echo $row['dob'];?>" class="input-lg" type="date"  id="dob" style="font-size:18px; width:400px" placeholder="DOB" autofocus required>
<br>
<br>

<!--<label for="gender" style="color:white">Gender</label>&nbsp &nbsp &nbsp &nbsp &nbsp
<select name="gender" value="<?php echo $row['gender'];?>" class="input-lg" autocomplete="off" id="gender"> 
<option value="<?php echo $row['gender'];?>">...Gender...</option>                                          
<option value="Male">Male</option>
<option value="Female">Female</option>
<option value="Other">Other</option>
</select>
<br>
<br>-->
<label for="address" style="color:white">Address</label>&nbsp &nbsp &nbsp &nbsp 
<input name="address" value="<?php echo $row['address'];?>" class="input-lg" type="address"  id="address" style="font-size:18px; width:200px" placeholder="Address" autofocus required>

<input name="country" value="<?php echo $row['state'];?>" class="input-lg" type="text"  id="country" style="font-size:18px; width:200px" placeholder="country" autofocus required>
<input name="city" value="<?php echo $row['city'];?>" class="input-lg" type="text"  id="city" style="font-size:18px; width:200px" placeholder="city" autofocus required>
<br>
<br>
<label for="Phone" style="color:white">Phone</label>&nbsp &nbsp &nbsp &nbsp &nbsp 
<input name="phone" value="<?php echo $row['phone'];?>" class="input-lg" type="text"  id="phone" style="font-size:18px; width:400px" placeholder="Phone" autofocus required>
<br>
<br>
<label for="email" style="color:white">Email</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<input name="email" value="<?php echo $row['email'];?>" class="input-lg" type="text"  id="email" style="font-size:18px; width:400px" placeholder="Email" autofocus required>
<br>
<br>

 <br>
 
 
 <center><input type="submit" class="btn btn-success" value="Edit" name="submit" id="submit" style="font-size:18px"></center>
</form>


	</div>	
	
 
	</div>
</div>



 </form>           

<?php 
}	
?>	
	
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
</body>
</html>
 