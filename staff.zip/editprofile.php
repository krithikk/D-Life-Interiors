<?php
include('../connection.php');
include("check_session.php");
	 
$id=$_SESSION['lid'];
//echo $id;
if($id>0)
{
$name=$_POST['name'];
//echo $name;
$dob=$_POST['dob'];
//echo $dob;
//$gend=$_POST['gender'];
//echo $gend;
$addr=$_POST['address'];
//echo $addr;
$countr=$_POST['country'];
//echo $countr;
$city=$_POST['city'];
//echo $city;
$phone=$_POST['phone'];
//echo $phone;
$email=$_POST['email'];
//echo $email;

$sql="update staffdetails set name='$name',dob='$dob',address='$addr',state='$countr',city='$city',phone='$phone',email='$email' where login_id='$id'";
$obj=new db();
$obj->execute($sql);
 }
 header("location:profile.php");
?>