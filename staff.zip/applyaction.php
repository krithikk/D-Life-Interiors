<?php
include("../connection.php");
include("check_session.php");
$bcid=$_SESSION['lid'];
//echo $bcid;
if(isset($_POST['submit']))
 {
	 $email=$_POST['email'];
$leavetype=$_POST['leavetype'];
$fromdate=$_POST['date'];  
$sess=$_POST['session'];
$description=$_POST['desc'];  



$sql="INSERT INTO tblleaves(email,LeaveType,FromDate,session,Description,login_id,status) VALUES('$email','$leavetype','$fromdate','$sess','$description','$bcid',0)";
$obj=new db();
$obj->execute($sql);



}
header("apply.php");

?>
    