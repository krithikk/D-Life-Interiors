<?php


 include("conn.php");
    $work = $_GET['work'];
	$_SESSION['work']=$work ;
	
	//echo"<script>
	//window.location='addwork.php';
	//</script>";
   

  
?>
