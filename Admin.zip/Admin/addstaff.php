<?php
  include("../connection.php");
  include("check_session.php");
//session_start();
//$lid=$_SESSION['lid'];
//$sel="SELECT * FROM category WHERE status='1'";
	//$obj=new db();
	//$select=$obj->execute($sel);
  
  //echo $lid;
  
  ?>

<!DOCTYPE html>
<html lang="en">

<head>
<script src="js/validate.js"> </script>
	
	<script type="text/javascript" language="javascript" src="javascripts/jquery.js"> </script>
	<script type="text/javascript" language="javascript" src="javascripts/staffval.js"> </script>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title> Admin Page</title>

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="css/zabuto_calendar.css">
  <link rel="stylesheet" type="text/css" href="lib/gritter/css/jquery.gritter.css" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
  <script src="lib/chart-master/Chart.js"></script>

  <!-- =======================================================
    Template Name: Dashio
    Template URL: https://templatemag.com/dashio-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="adminhome.php" class="logo"><b>D'LIFE<span>Interiors</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start 
        <ul class="nav top-menu">
          <!-- settings start 
          <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-tasks"></i>
              <span class="badge bg-theme">4</span>
              </a>
            <ul class="dropdown-menu extended tasks-bar">
              <div class="notify-arrow notify-arrow-green"></div>
              <li>
                <p class="green">You have 4 pending tasks</p>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Dashio Admin Panel</div>
                    <div class="percent">40%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                      <span class="sr-only">40% Complete (success)</span>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Database Update</div>
                    <div class="percent">60%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
                      <span class="sr-only">60% Complete (warning)</span>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Product Development</div>
                    <div class="percent">80%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                      <span class="sr-only">80% Complete</span>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Payments Sent</div>
                    <div class="percent">70%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%">
                      <span class="sr-only">70% Complete (Important)</span>
                    </div>
                  </div>
                </a>
              </li>
              <li class="external">
                <a href="#">See All Tasks</a>
              </li>
            </ul>
          </li>-->
          <!-- settings end -->
          <!-- inbox dropdown start
          <li id="header_inbox_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-envelope-o"></i>
              <span class="badge bg-theme">5</span>
              </a>
            <ul class="dropdown-menu extended inbox">
              <div class="notify-arrow notify-arrow-green"></div>
              <li>
                <p class="green">You have 5 new messages</p>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-zac.jpg"></span>
                  <span class="subject">
                  <span class="from">Zac Snider</span>
                  <span class="time">Just now</span>
                  </span>
                  <span class="message">
                  Hi mate, how is everything?
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-divya.jpg"></span>
                  <span class="subject">
                  <span class="from">Divya Manian</span>
                  <span class="time">40 mins.</span>
                  </span>
                  <span class="message">
                  Hi, I need your help with this.
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-danro.jpg"></span>
                  <span class="subject">
                  <span class="from">Dan Rogers</span>
                  <span class="time">2 hrs.</span>
                  </span>
                  <span class="message">
                  Love your new Dashboard.
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-sherman.jpg"></span>
                  <span class="subject">
                  <span class="from">Dj Sherman</span>
                  <span class="time">4 hrs.</span>
                  </span>
                  <span class="message">
                  Please, answer asap.
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">See all messages</a>
              </li>
            </ul>
          </li>-->
          <!-- inbox dropdown end -->
          <!-- notification dropdown start
          <li id="header_notification_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-bell-o"></i>
              <span class="badge bg-warning">7</span>
              </a>
            <ul class="dropdown-menu extended notification">
              <div class="notify-arrow notify-arrow-yellow"></div>
              <li>
                <p class="yellow">You have 7 new notifications</p>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-danger"><i class="fa fa-bolt"></i></span>
                  Server Overloaded.
                  <span class="small italic">4 mins.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-warning"><i class="fa fa-bell"></i></span>
                  Memory #2 Not Responding.
                  <span class="small italic">30 mins.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-danger"><i class="fa fa-bolt"></i></span>
                  Disk Space Reached 85%.
                  <span class="small italic">2 hrs.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-success"><i class="fa fa-plus"></i></span>
                  New User Registered.
                  <span class="small italic">3 hrs.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">See all notifications</a>
              </li>
            </ul>
          </li>-->
          <!-- notification dropdown end -->
        </ul>
        <!--  notification end -->
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="logout.php">Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="adminhome.php"><img src="img/ui-divya.jpg" class="img-circle" width="80"></a></p>
          <h5 class="centered">Admin</h5>
          <li class="mt">
            <a class="active" href="adminhome.php">
              <i class="fa fa-dashboard"></i>
              <span>admin@gmail.com</span>
              </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-desktop"></i>
              <span> CATEGORIES AND PRODUCTS</span>
              </a>
            <ul class="sub">
              <li><a href="addcate.php">CATEGORIES</a></li>
			  <li><a href="addsubcat.php">SUBCATEGORIES</a></li>
			   <!-- <li><a href="addsubcat2.php">SUBCATEGORIES2</a></li>-->
			  <li><a href="addprod.php">PRODUCTS</a></li>
			  	  <li><a href="productsub.php">PRODUCTSUB</a></li>
				  	<!--  <li><a href="prosub2.php">PRODUCTSUB2</a></li>
             <li><a href="buttons.html">TEAM</a></li>-->
              
            </ul
			<li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span> LEAVE</span>
              </a>
            <ul class="sub">
              <li><a href="addleave.php">ADD LEAVETYPE</a></li>
			  <li><a href="viewleave.php">VIEW LEAVE REQUEST</a></li>
			  <!--<li><a href="viewcategory.php">CATEGORIES</a></li>-->
              <li><a href="approved.php">APPROVED LEAVES</a></li>
              <li><a href="rejected.php">REJECTED LEAVES</a></li>
            </ul>
          </li>
		  <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>VIEW</span>
              </a>
            <ul class="sub">
              <li><a href="viewcustm.php">CUSTOMERS</a></li>
			   <li><a href="viewestimate.php">ESTIMATE REQUEST</a></li>
			   <li><a href="vieworder.php">ORDERS</a></li>
			    <li><a href="viewpay.php">PAYMENT DETAILS</a></li>
			   <li><a href="viewpro.php">PRODUCTS</a></li>
			   <li><a href="viewprosub.php">SUBPRODUCTS</a></li>
			   <li><a href="viewmsg.php">MESSAGE</a></li>
			   <!--<li><a href="viewpro.php">PRODUCTS</a></li>
			   <!--<li><a href="viewpro.php">PRODUCTS</a></li>
			 <li><a href="viewcategory.php">CATEGORIES</a></li>
              <li><a href="vieworder.php">ORDERS</a></li>-->
              
            </ul>
			<li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>JOB</span>
              </a>
            <ul class="sub">
              <li><a href="viewcareer.php">JOB REQUEST</a></li>
			   <li><a href="approvedjob.php">APPROVED REQUEST</a></li>
			   <li><a href="rejectedjob.php">REJECTED REQUEST</a></li>
			   
			   <!--<li><a href="viewpro.php">PRODUCTS</a></li>
			 <li><a href="viewcategory.php">CATEGORIES</a></li>
              <li><a href="vieworder.php">ORDERS</a></li>-->
              
            </ul>
			<li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-book"></i>
              <span>STAFFS</span>
              </a>
			<ul class="sub">
              <li><a href="addstaff.php">ADD STAFF</a></li>
			  <li><a href="addjob.php">ADD JOBTYPE</a></li>
			  <li><a href="jobass.php">ASSIGN JOB</a></li>
			    <li><a href="viewstaff.php">MANAGE STAFF</a></li>
				<li><a href="addwork.php">WORK ASSIGN</a></li>
				<li><a href="request.php">WORK EXTEND</a></li>
				 <li><a href="workapp.php">WORK APPROVED</a></li>
				 	 <li><a href="workrej.php">WORK REJECTED</a></li>
				
			  </ul>
			  <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-book"></i>
              <span>PACKAGES</span>
              </a>
			<ul class="sub">
              <li><a href="addpackage.php">ADD PACKAGES</a></li>
			  <li><a href="viewpack.php">VIEW PACKAGES</a></li>
			  </ul>
			  <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-book"></i>
              <span>SERVICES</span>
              </a>
			<ul class="sub">
              <li><a href="addservice.php">ADD SERVICES TYPE</a></li>
				 <li><a href="viewservice.php">VIEW SERVICES REQUEST</a></li>
				 <li><a href="servapprove.php">APPROVED REQUEST</a></li>
			   <li><a href="servreject.php">REJECTED REQUEST</a></li>
			  </ul>
          <!--<li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-cogs"></i>
			  
              <span>COMPONENTS</span>
              </a>
            <ul class="sub">
              <li><a href="grids.html">Grids</a></li>
              <li><a href="calendar.html">Calendar</a></li>
              <li><a href="gallery.html">Gallery</a></li>
              <li><a href="todo_list.html">Todo List</a></li>
              <li><a href="dropzone.html">Dropzone File Upload</a></li>
              <li><a href="inline_editor.html">Inline Editor</a></li>
              <li><a href="file_upload.html">Multiple File Upload</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-book"></i>
              <span>Extra Pages</span>
              </a>
            <ul class="sub">
              <li><a href="blank.html">Blank Page</a></li>
              <li><a href="login.html">Login</a></li>
              <li><a href="lock_screen.html">Lock Screen</a></li>
              <li><a href="profile.html">Profile</a></li>
              <li><a href="invoice.html">Invoice</a></li>
              <li><a href="pricing_table.html">Pricing Table</a></li>
              <li><a href="faq.html">FAQ</a></li>
              <li><a href="404.html">404 Error</a></li>
              <li><a href="500.html">500 Error</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>Forms</span>
              </a>
            <ul class="sub">
              <li><a href="form_component.html">Form Components</a></li>
              <li><a href="advanced_form_components.html">Advanced Components</a></li>
              <li><a href="form_validation.html">Form Validation</a></li>
              <li><a href="contactform.html">Contact Form</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-th"></i>
              <span>Data Tables</span>
              </a>
            <ul class="sub">
              <li><a href="basic_table.html">Basic Table</a></li>
              <li><a href="responsive_table.html">Responsive Table</a></li>
              <li><a href="advanced_table.html">Advanced Table</a></li>
            </ul>
          </li>
          <li>
            <a href="inbox.html">
              <i class="fa fa-envelope"></i>
              <span>Mail </span>
              <span class="label label-theme pull-right mail-info">2</span>
              </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class=" fa fa-bar-chart-o"></i>
              <span>Charts</span>
              </a>
            <ul class="sub">
              <li><a href="morris.html">Morris</a></li>
              <li><a href="chartjs.html">Chartjs</a></li>
              <li><a href="flot_chart.html">Flot Charts</a></li>
              <li><a href="xchart.html">xChart</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-comments-o"></i>
              <span>Chat Room</span>
              </a>
            <ul class="sub">
              <li><a href="lobby.html">Lobby</a></li>
              <li><a href="chat_room.html"> Chat Room</a></li>
            </ul>
          </li>
          <li>
            <a href="google_maps.html">
              <i class="fa fa-map-marker"></i>
              <span>Google Maps </span>
              </a>
          </li>
        </ul>-->
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
   
                  <script>
                    var doughnutData = [{
                        value: 70,
                        color: "#FF6B6B"
                      },
                      {
                        value: 30,
                        color: "#fdfdfd"
                      }
                    ];
                    var myDoughnut = new Chart(document.getElementById("serverstatus01").getContext("2d")).Doughnut(doughnutData);
                  </script>
                  
                  <script>
                    var doughnutData = [{
                        value: 60,
                        color: "#1c9ca7"
                      },
                      {
                        value: 40,
                        color: "#f68275"
                      }
                    ];
                    var myDoughnut = new Chart(document.getElementById("serverstatus02").getContext("2d")).Doughnut(doughnutData);
                  </script>
                  
                  <script>
                    var doughnutData = [{
                        value: 60,
                        color: "#2b2b2b"
                      },
                      {
                        value: 40,
                        color: "#fffffd"
                      }
                    ];
                    var myDoughnut = new Chart(document.getElementById("serverstatus03").getContext("2d")).Doughnut(doughnutData);
                  </script>
               
              <script>
                var doughnutData = [{
                    value: 70,
                    color: "#4ECDC4"
                  },
                  {
                    value: 30,
                    color: "#fdfdfd"
                  }
                ];
                var myDoughnut = new Chart(document.getElementById("newchart").getContext("2d")).Doughnut(doughnutData);
              </script>
            </div>
           	 <?php include("include/header.php");?>
   	<div class="container-fluid">
	<?php include("include/side_bar.php");?>
    
	
        <div class="col-sm-9" style="margin-left:10px"> 
<div class="panel-heading" style="background-color:pink">
	<h1>Add Staff</h1></div><br>

<div style="overflow-x:scroll;">


<form action="staff_action.php" name="form1" method="post" id="form1">

<label for="name">Name</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<input name="name" class="input-lg" type="text"  id="name" style="font-size:18px; width:400px" placeholder="Full Name"  >
<span id="fullname_error_message" style="color:red"></span><br><br>
<br>

<label for="dob">DOB</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<input name="dob" class="input-lg" type="date"  id="dob" style="font-size:18px; width:400px" placeholder="DOB" >
<span id="dob_error_message" style="color:red"></span><br><br>
<br>

<label for="gender">Gender</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
<select  name="gender" id="gender" class="input-lg" autocomplete="off" >
<option value="gender">...Gender...</option>                                          
<option value="Male">Male</option>
<option value="Female">Female</option>
<option value="Other">Other</option>
</select>
<span id="gender_error_message" style="color:red"></span>
<br>
<br>
<label for="address">Address</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<input name="address" class="input-lg" type="address"  id="address" style="font-size:18px; width:400px" placeholder="Address"  >
<span id="address_error_message" style="color:red"></span><br><br>

<!--<label for="country">Country</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
<input name="country" class="input-lg" type="text"  id="country" style="font-size:18px; width:200px" placeholder="country" autofocus required>
<span id="country_error_message" style="color:red"></span>-->

<label for="state">State</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp
<select  name="country"  id="country" class="input-lg" style="font-size:18px; width:200px" autocomplete="off" >
<option value="select">...state...</option>                                          
<option value="kerala">Kerala</option>
</select>
<span id="country_error_message" style="color:red"></span>

<label for="city">City</label>&nbsp &nbsp 
<input name="city" class="input-lg" type="text"  id="city" style="font-size:18px; width:200px" placeholder="city"  >
<span id="city_error_message" style="color:red"></span>
<br>
<br>
<label for="Phone">Phone</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<input name="Phone" class="input-lg" type="text"  id="Phone" style="font-size:18px; width:400px" placeholder="Phone"  >
<span id="phone_error_message" style="color:red"></span>
<br>
<br>

<label for="email">Email</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
<input name="email" class="input-lg" type="text"  id="email" style="font-size:18px; width:400px" placeholder="Email"  >
<span id="email_error_message" style="color:red"></span>
<br>
<br>
<label for="password">Password</label>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
<input name="password" class="input-lg" type="password"  id="password" style="font-size:18px; width:400px" placeholder="Password"  >
<span id="pwd_error_message" style="color:red"></span>
 <br>
 <br>
<!--<label for="cpassword">Confirm Pass</label> &nbsp &nbsp
<input name="cpwd" class="input-lg" type="password"  id="cpwd" style="font-size:18px; width:400px" placeholder="Confirm Password" autofocus required>
<span id="cpwd_error_message" style="color:red"></span>-->

 <center><input type="submit" class="btn btn-success" name="submit" id="submit" style="font-size:18px"></center>
</form>


	</div>	
	
 
	</div>
</div></div></div>
<?php include("include/js.php"); ?>


 </form>           
    
    
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="lib/jquery/jquery.min.js"></script>

  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="lib/jquery.scrollTo.min.js"></script>
  <script src="lib/jquery.nicescroll.js" type="text/javascript"></script>
  <script src="lib/jquery.sparkline.js"></script>
  <!--common script for all pages-->
  <script src="lib/common-scripts.js"></script>
  <script type="text/javascript" src="lib/gritter/js/jquery.gritter.js"></script>
  <script type="text/javascript" src="lib/gritter-conf.js"></script>
  <!--script for this page-->
  <script src="lib/sparkline-chart.js"></script>
  <script src="lib/zabuto_calendar.js"></script>
  <!--<script type="text/javascript">
    $(document).ready(function() {
      var unique_id = $.gritter.add({
        // (string | mandatory) the heading of the notification
        title: 'Welcome to Dashio!',
        // (string | mandatory) the text inside the notification
        text: 'Hover me to enable the Close Button. You can hide the left sidebar clicking on the button next to the logo.',
        // (string | optional) the image to display on the left
        image: 'img/ui-sam.jpg',
        // (bool | optional) if you want it to fade out on its own or just sit there
        sticky: false,
        // (int | optional) the time you want it to be alive for before fading out
        time: 8000,
        // (string | optional) the class name you want to apply to that specific message
        class_name: 'my-sticky-class'
      });

      return false;
    });
  </script>-->
  <script type="application/javascript">
    $(document).ready(function() {
      $("#date-popover").popover({
        html: true,
        trigger: "manual"
      });
      $("#date-popover").hide();
      $("#date-popover").click(function(e) {
        $(this).hide();
      });

      $("#my-calendar").zabuto_calendar({
        action: function() {
          return myDateFunction(this.id, false);
        },
        action_nav: function() {
          return myNavFunction(this.id);
        },
        ajax: {
          url: "show_data.php?action=1",
          modal: true
        },
        legend: [{
            type: "text",
            label: "Special event",
            badge: "00"
          },
          {
            type: "block",
            label: "Regular event",
          }
        ]
      });
    });

    function myNavFunction(id) {
      $("#date-popover").hide();
      var nav = $("#" + id).data("navigation");
      var to = $("#" + id).data("to");
      console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
    }
  </script>
</body>

</html>
