<?php
include("check_session.php");
//session_start();
$id=$_GET['id'];
echo $id;
include("../connection.php");
$upd="update jobuser set status=1 where jobuserid=$id";
$obj=new db();
$obj->execute($upd);

if($obj)
  {
 ?>
 <script>
  alert("job request approved Sucessfully");
  window.location="viewcareer.php";
</script>
<?php
  }
else
{
	?>
	<script>
  alert("job request not approved Sucessfully");
  window.location="viewcareer.php";
  </script>
   <?php
}
//header("location:viewcareer.php");
?>