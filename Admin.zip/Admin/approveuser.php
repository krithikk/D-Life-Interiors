
<?php
include("check_session.php");
//session_start();
$id=$_GET['id'];
echo $id;
include("../connection.php");
$upd="update tblleaves set status=2 where leaveid=$id";
$obj=new db();
$obj->execute($upd);
if($obj)
  {
 ?>
 <script>
  alert("leave request approved Sucessfully");
  window.location="viewleave.php";
</script>
<?php
  }
else
{
	?>
	<script>
  alert("leave request not approved Sucessfully");
  window.location="viewleave.php";
  </script>
   <?php
}
//header("location:viewleave.php");
?>