<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title>D'Life Interior Design System </title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Interior Decor Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
	
	<!-- css files -->
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' /><!-- bootstrap css -->
    <link href="css/style.css" rel='stylesheet' type='text/css' /><!-- custom css -->
    <link href="css/fontawesome-all.css" rel="stylesheet" /><!-- fontawesome css -->
	<!-- //css files -->
	
	<!-- google fonts -->
	<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=latin-ext" rel="stylesheet">
	<!-- //google fonts -->
	
</head>
<body>

<!-- header -->
<header>
	<div class="container">
		<!-- top nav -->
		<nav class="top_nav d-flex pt-4">
			<!-- logo -->
			<h1>
				<a class="navbar-brand" href="index.html">D'Life Interior 
				</a>
			</h1>
			
			</div>
		</nav>
		<!-- //top nav -->
		<!-- bottom nav -->
		<nav class="navbar navbar-expand-lg navbar-light justify-content-center">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav mx-auto text-center">
					<li class="nav-item">
						<a class="nav-link  active" href="index.php">Home
							<span class="sr-only">(current)</span>
						</a>
					</li>
					
					
					<li class="nav-item">
						<a class="nav-link" href="gallery.php">Products Gallery</a>
					</li>
					
				
					
				<li class="nav-item">
						<a class="nav-link" href="login\login.php">login</a>
					</li>
					
					
					<li class="dropdown nav-item">
						<a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">Registraton
							<b class="caret"></b>
						</a>
						<ul class="dropdown-menu agile_short_dropdown">
							<li>
								<a href="user reg\reg.php">User here...</a>
							</li>
							<!--<li>
								<a href="team reg\team_reg.php">Team...</a>
							</li>-->
						</ul>
					
					
				</ul>
			</div>
		  
		</nav>
	
</header>
					</li>
				</ul>
			</div>
		</nav>
		<!-- //bottom nav -->
	</div>
	<!-- //header container -->
</header>
<!-- //header -->

<!-- banner -->
<div class="banner layer" id="home">
	<div class="container">
		<div class="banner-text">
			<div class="slider-info text-center">
				<div class="agileinfo-logo">
					<h2> Interior Technology </h2>
				</div>
				<h3 class="txt-w3_agile"> Decorating Ideas for your House</h3>
			</div>
			<div class="row banner-grids text-center mt-md-5 mt-3">
				<div class="col-lg-3 col-md-2">
					<img src="images/bathing.png" class="img-fluid" alt="" />
				</div>
				<div class="col-lg-6 col-md-8 banner-para">
					<p class="">“Made for you” may be an accurate phrase to express what we do in interiors. This company designs and executes exquisite home interiors in Kochi, other places in Kerala and since 2004.DLIFE’s fully equipped modular kitchen is distinct with its unique design and most modern features. We plan and make contemporary style furniture for bedrooms, living and dining rooms as well.</p>
					<!--<a href="#myModal_btn1" data-toggle="modal" data-target="#myModal_btn1">Read More</a>-->
				</div>
				<div class="col-lg-3 col-md-2">
					<img src="images/chair.png" class="img-fluid" alt="" />
				</div>
			</div>
			<div class="thim-click-to-bottom text-center">
				<div class="rotate">
					<a href="#about" class="scroll">
					   <i class="fas fa-angle-double-down"></i>
					</a>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- footer -->
<footer class="py-5 bg-light">
	<div class="container py-md-3">
		<div class="row footer-grids">
			<div class="col-lg-3 col-md-6">
				<h4 class="mb-4">Contact Us</h4>
				<p> <span class="fas mr-2 fa-map-marker"></span> 51/24A-2,1st Floor
Tharayil Tower
Poonithura, Vyttila-682019
Ernakulam
Kerala, India</p>
				<p class="my-2"><span class="fas mr-2 fa-envelope-open"></span> <a href="mailto:info@example.com">dlife@gmail.com</a></p>
				<p><span class="fas mr-2 fa-phone-volume"></span> 919874561232</p>
			</div>
			<div class="col-lg-3 mt-md-0 mt-5 col-md-6">
				<h4 class="mb-4">Company links</h4>
				<p><a href="#">Terms and Conditions</a></p>
				<p><a href="#">Privacy Policy</a></p>
				<p><a href="#">License Aggrement</a></p>
			</div>
			<div class="col-lg-6 mt-lg-0 mt-5 brands">
				<h4 class="mb-4">Our Partners</h4>
				<ul>
					<li><img src="images/brand1.png" class="img-fluid" alt="" /></li>
					<li><img src="images/brand2.png" class="img-fluid" alt="" /></li>
					<li><img src="images/brand3.png" class="img-fluid" alt="" /></li>
					<li><img src="images/brand4.png" class="img-fluid" alt="" /></li>
				</ul>
			</div>
		</div>
		<!--<div class="text-center mt-5 pt-4 copyright">
			<p class="">© 2018 Interior Decor. All rights reserved | Design by
			<a href="http://w3layouts.com"> W3layouts.</a>
		</p>
		</div>
	</div>-->
</footer>
<!-- //footer -->

<!-- sign up Modal -->
<div class="modal fade" id="myModal_btn" tabindex="-1" role="dialog" aria-labelledby="myModal_btn" aria-hidden="true">
	<div class="agilemodal-dialog modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Register Now</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body pt-3 pb-5 px-sm-5">
				<div class="row">
					<div class="col-md-6 mx-auto">
						<img src="images/t4.png" class="img-fluid" alt="login_image" />
						<p class="pt-5">User registration</p>
					</div>
					<div class="col-md-6">
						<form action="#" method="post">
							<div class="form-group">
								<label for="recipient-name1" class="col-form-label">Your Name</label>
								<input type="text" class="form-control" placeholder=" " name="Name" id="recipient-name1" required="">
							</div>
							<div class="form-group">
								<label for="recipient-email" class="col-form-label">Email</label>
								<input type="email" class="form-control" placeholder=" " name="Email" id="recipient-email" required="">
							</div>
							<div class="form-group">
								<label for="recipient-email" class="col-form-label">contact</label>
								<input type="email" class="form-control" placeholder=" " name="Email" id="recipient-email" required="">
							</div>
							<div class="form-group">
								<label for="password1" class="col-form-label">Password</label>
								<input type="password" class="form-control" placeholder=" " name="Password" id="password1" required="">
							</div>
							<div class="form-group">
								<label for="password2" class="col-form-label">Confirm Password</label>
								<input type="password" class="form-control" placeholder=" " name="Confirm Password" id="password2" required="">
							</div>
							<div class="sub-w3l">
								<div class="sub-agile">
									<input type="checkbox" id="brand2" value="">
									<label for="brand2" class="mb-3">
										<span></span>I Accept to the Terms & Conditions</label>
								</div>
							</div>
							<div class="right-w3l">
								<input type="submit" class="form-control" value="Register">
							</div>
						</form>
						<p class="text-center mt-3">Already a member?
							<a href="#" data-toggle="modal" data-target="#exampleModal1" class="text-dark login_btn">
								Login Now</a>
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- //signup modal -->
<!-- signin Modal -->
<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModal1" aria-hidden="true">
	<div class="agilemodal-dialog modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Login</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body  pt-3 pb-5 px-sm-5">
				<div class="row">
					<div class="col-md-6">
						<img src="images/t3.png" class="img-fluid" alt="login_image" />
						<p class="pt-5">Login details</p>
					</div>
                    
					<div class="col-md-6 align-self-center">
						<form action="#" method="post">
							<div class="form-group">
								<label for="recipient-name" class="col-form-label">Emailid</label>
								<input type="text" class="form-control" placeholder=" " name="Name" id="recipient-name" required="">
							</div>
							<div class="form-group">
								<label class="col-form-label">Password</label>
								<input type="password" class="form-control" placeholder=" " name="Password" required="">
							</div>
							<div class="right-w3l">
								<input type="submit" class="form-control" value="Login">
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- signin Modal -->

<!-- Vertically centered Modal -->
    <div class="modal fade" id="myModal_btn1" tabindex="-1" role="dialog" aria-labelledby="myModal_btn1" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title text-capitalize text-center" id="exampleModalLongTitle"> Interior Decor</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<img src="images/banner.jpg" class="img-fluid mb-3" alt="Modal Image">
				Vivamus eget est in odio tempor interdum. Mauris maximus fermentum arcu, ac finibus ante. Sed mattis risus at ipsum elementum,
				ut auctor turpis cursus. Sed sed odio pharetra, aliquet velit cursus, vehicula enim. Mauris porta aliquet magna, eget laoreet ligula.
				Sed mattis risus at ipsum elementum, ut auctor turpis cursus.
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-primary">Save Changes</button>
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>


	
<!-- //Vertically centered Modal -->

    <!-- js -->
    <script src="js/jquery-2.2.3.min.js"></script>
    <script src="js/bootstrap.js"></script>
    <!-- //js -->

	<!-- Responsiveslides -->
    <script src="js/responsiveslides.min.js"></script>
    <script>
        // You can also use"$(window).load(function() {"
        $(function () {
            // Slideshow 4
            $("#slider3").responsiveSlides({
                auto: true,
                pager: true,
                nav: false,
                speed: 500,
                namespace: "callbacks",
                before: function () {
                    $('.events').append("<li>before event fired.</li>");
                },
                after: function () {
                    $('.events').append("<li>after event fired.</li>");
                }
            });

        });
    </script>
    <!-- // Responsiveslides -->

	<script src="js/smoothscroll.js"></script><!-- Smooth scrolling -->

    <!-- start-smoth-scrolling -->
    <script src="js/move-top.js"></script>
    <script src="js/easing.js"></script>
    <script>
        jQuery(document).ready(function ($) {
            $(".scroll").click(function (event) {
                event.preventDefault();
                $('html,body').animate({
                    scrollTop: $(this.hash).offset().top
                }, 900);
            });
        });
    </script>
    <script>
        $(document).ready(function () {
            /*
			var defaults = {
				  containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
			 };
			*/

            $().UItoTop({
                easingType: 'easeOutQuart'
            });

        });
    </script>
    <!-- //end-smoth-scrolling -->
	

</body>
</html>