-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2020 at 10:29 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dlife_inter`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `book_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `zipcode` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `proname` varchar(500) NOT NULL,
  `login_id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`book_id`, `name`, `email`, `address`, `city`, `zipcode`, `phone`, `district`, `picture`, `proname`, `login_id`, `status`) VALUES
(10, 'sandeep ks ', 'sandeep@gmail.com', 'puthenpurayil', 'chengannur', '789456', '8078919098', 'ktm', 'images (1).jpg', 'Master bedroom', 205, 1),
(11, 'sandeep ks ', 'sandeep@gmail.com', 'madhavam', 'chengannur', '689123', '7788994455', 'ktm', 'images (1).jpg', 'Stand With Audio Towers', 205, 0),
(13, 'Rema Krishna', 'rema@gmail.com', 'Vaipur', 'Mallappaly', '789456', '9446518098', 'path', 'a3.jpg', 'Master bedroom', 220, 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `categoryname` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `categoryname`, `status`) VALUES
(33, 'Living room', '1'),
(34, 'Bedroom', '1'),
(35, 'outdoor', '0'),
(36, 'Wall art', '0'),
(37, 'Dining room', '0'),
(38, 'Study room', '1'),
(39, 'Store room', '1'),
(40, 'Decor', '0'),
(41, 'Home Furnishing', '0'),
(42, 'Photo Frames', '0'),
(43, 'Indoor Plants', '0'),
(44, 'Flooring', '0'),
(45, 'Ceiling', '0'),
(46, 'Paints', '0'),
(47, 'Curtains', '0'),
(48, 'Door', '0'),
(49, 'Windows', '0'),
(50, 'Mosquito net', '0'),
(51, 'Fans', '0'),
(52, 'Ac', '0'),
(53, 'Kitchen', '1'),
(54, 'Bathroom', '0'),
(59, 'Wadrobes', '0'),
(60, 'TV units', '1'),
(61, '', '0'),
(62, '', '0'),
(63, '', '0'),
(64, 'bathroom design', '0'),
(65, 'fan ac', '0'),
(66, 'ac fan', '0');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `contactid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `comments` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`contactid`, `name`, `email`, `phone`, `comments`, `status`) VALUES
(1, 'sandeep ks', 'kkrithi97@gmail.com', '7894561230', 'need more details', 1),
(2, 'sandeep ks', 'sandeep123@gmail.com', '7894561230', 'send me some details about your package', 1);

-- --------------------------------------------------------

--
-- Table structure for table `estimate`
--

CREATE TABLE `estimate` (
  `estid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `comments` varchar(100) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `estimate`
--

INSERT INTO `estimate` (`estid`, `name`, `email`, `phone`, `location`, `comments`, `picture`, `status`) VALUES
(1, 'sandeep ks', 'sandeep@gmail.com', '7894563210', 'chengannur', 'kitchen floor plan', 'hotel.png', 1),
(2, 'sandeep ks', 'sandeep123@gmail.com', '7894563210', 'pala', 'need an estimate', 'Screenshot (9).png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `jobasstbl`
--

CREATE TABLE `jobasstbl` (
  `assid` int(11) NOT NULL,
  `staffname` varchar(100) NOT NULL,
  `jobname` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobasstbl`
--

INSERT INTO `jobasstbl` (`assid`, `staffname`, `jobname`, `status`, `login_id`) VALUES
(8, 'vipin', 'Painting', 1, 201),
(9, 'krithi', 'Painting', 1, 194),
(10, 'litty', 'Designing', 0, 203),
(11, 'minnu mol', 'Curtaining', 0, 179),
(12, 'minnu mol', 'Designing', 0, 179),
(13, 'minnu raj', 'Curtaining', 1, 204),
(14, 'minnu raj', 'Designing', 1, 204);

-- --------------------------------------------------------

--
-- Table structure for table `jobtbl`
--

CREATE TABLE `jobtbl` (
  `jobid` int(11) NOT NULL,
  `jobname` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobtbl`
--

INSERT INTO `jobtbl` (`jobid`, `jobname`, `status`) VALUES
(1, 'Designing', 1),
(2, 'Painting', 1),
(3, 'Curtaining', 1);

-- --------------------------------------------------------

--
-- Table structure for table `jobuser`
--

CREATE TABLE `jobuser` (
  `jobuserid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `job` varchar(100) NOT NULL,
  `code` varchar(100) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobuser`
--

INSERT INTO `jobuser` (`jobuserid`, `name`, `email`, `phone`, `place`, `job`, `code`, `picture`, `status`) VALUES
(4, 'sandeep ks', 'sandeep@gmail.com', '7894561230', 'Mannanm', 'Sales Consultant', '', 'Admin.java', 1),
(5, 'sandeep', 'sandeep@g.com', '9874563210', 'kollam', 'Electricians', '', 'ho.png', 2),
(6, 'appu', 'appu@g.com', '9874563210', 'ktym', 'Designer', '', 'ho.png', 2),
(7, 'kripa', 'kk@g.com', '7894563210', 'kkk', 'Sales Consultant', '', 'ho.png', 0),
(8, 'sandeep ks', 'sandeep12@gmail.com', '7894561230', 'chengannur', 'Sales Consultant', '2fe26d', 'Client.java', 0);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `login_id` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `role` varchar(20) NOT NULL,
  `logstatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`login_id`, `email`, `password`, `status`, `role`, `logstatus`) VALUES
(3, 'admin@gmail.com', 'admin', '1', 'admin', 0),
(198, 'appu1@gmail.com', 'appuvipin', '0', 'user', 1),
(199, 'asha@gmail.com', 'krithi123', '2', 'user', 1),
(201, 'appuvipin123@gmail.com', 'appu123', '0', 'staff', 1),
(203, 'litty4ever@gmail.com', 'litty123', '0', 'staff', 1),
(204, 'minnuraj@mca.ajce.in', 'minnu1234', '0', 'staff', 1),
(205, 'sandeep@gmail.com', 'sandeep1234', '0', 'user', 1),
(214, 'krithi97@gmail.com', 'krithi123', '0', 'user', 1),
(219, 'krishnakrithi97@gmail.com', 'krishna123', '0', 'staff', 1),
(222, 'krishkripa1986@gmail.com', 'kripa123', '0', 'staff', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orderconf`
--

CREATE TABLE `orderconf` (
  `confid` int(11) NOT NULL,
  `stname` varchar(100) NOT NULL,
  `dow` varchar(100) NOT NULL,
  `doww` varchar(100) NOT NULL,
  `exp` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `advance` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `proname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderconf`
--

INSERT INTO `orderconf` (`confid`, `stname`, `dow`, `doww`, `exp`, `amount`, `advance`, `status`, `login_id`, `proname`) VALUES
(18, 'litty', '2020-05-02', '2020-05-10', '1000', '200000', '90000', 1, 205, 'pallet racking'),
(21, 'minnu raj', '2020-06-05', '2020-06-12', '1000', '1500000', '500000', 1, 220, 'Master bedroom');

-- --------------------------------------------------------

--
-- Table structure for table `packtbl`
--

CREATE TABLE `packtbl` (
  `packid` int(11) NOT NULL,
  `namee` varchar(100) NOT NULL,
  `descr` varchar(500) NOT NULL,
  `price` varchar(100) NOT NULL,
  `adprice` varchar(100) NOT NULL,
  `proname` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `packtbl`
--

INSERT INTO `packtbl` (`packid`, `namee`, `descr`, `price`, `adprice`, `proname`, `status`, `name`, `login_id`) VALUES
(3, 'Kitchen designs', 'Material	:Wooden,\r\nKitchen Shape	:L Shape,\r\nModular Kitchen Components:Kitchen Cabinets,\r\nFinish	:Matte,\r\nCounter Height:	2.5-3 Feet', '20lakh', '10lakh', 'kitchen-l-shaped', 1, '11', 0),
(11, 'Tv units', 'Material: Beech\r\nW x H x D: 122 cm x 61 cm x 38 cm (4 ft x 2 ft x 1 ft 2 in)\r\nIdeal TV Size: 105 inch,\r\nNumber of Drawers: 2, Number of Open Shelves: 3, Number, of Closed Shelves: 1,\r\nDelivery Condition: Knock Down - Delivered in non-assembled pieces, installation by service partner', '50000', '10000', 'Console TV units', 1, '10', 0),
(12, 'Tv units', 'Material: Plywood,\r\nW x H x D: 49 mm x 18 mm x 18 mm (1 in)\r\nIdeal TV Size: 65 inch,\r\nNumber of Drawers: 0, Number of Open Shelves: 2, Number of Closed Shelves: 0\r\nDelivery Condition: Pre Assembled (Ready to Use)', '80000', '40000', 'Stand With Audio Towers', 1, '14', 0),
(16, 'Store Room', 'Product name	Warehouse Heavy Duty Steel Pallet Racking\r\nMaterial	Q235B STEEL	Color	RAL system\r\nPitch	50mm/50.8mm/75mm/76.2mm	Surface\r\nPowder coating or galvanized\r\nSize	H*W*D Customer Size	Structure	Assembled Freely\r\nheight	maximum 12000mm	Capacity	maximum 4500kg/level\r\nwidth	1350mm - 3900mm	Thickness	1.5mm-3.0mm', '200000', '90000', 'pallet racking', 1, '15', 3),
(17, 'Bedroom design', 'A bedroom is a room of a house, mansion, castle, palace, hotel, dormitory, apartment, condominium, duplex or townhouse where people sleep. A typical western bedroom contains as bedroom furniture one or two beds, a clothes closet, and bedside table and dressing table, both of which usually contain drawers.', '120000', '200000', 'Master bedroom', 1, 'Rema Krishna', 3);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `paymid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`paymid`, `name`, `email`, `phone`, `amount`, `login_id`) VALUES
(22, 'sandeep ', 'sandeep@gmail.com', '8956234101', '100', 205),
(23, 'sandeep ', 'sandeep@gmail.com', '8956234101', '100', 205),
(24, 'sandeep ', 'sandeep@gmail.com', '8956234101', '1000', 205),
(25, 'sandeep ', 'sandeep@gmail.com', '8956234101', '1000', 205),
(26, 'sandeep ', 'sandeep@gmail.com', '8956234101', '1000', 205);

-- --------------------------------------------------------

--
-- Table structure for table `pendingtbl`
--

CREATE TABLE `pendingtbl` (
  `pendid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dow` varchar(100) NOT NULL,
  `doww` varchar(100) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pendingtbl`
--

INSERT INTO `pendingtbl` (`pendid`, `email`, `dow`, `doww`, `Description`, `status`, `login_id`) VALUES
(1, 'appuvipin123@gmail.c', '2020-05-01', '2020-05-05', 'need more time to complete work.', 2, 201);

-- --------------------------------------------------------

--
-- Table structure for table `product1`
--

CREATE TABLE `product1` (
  `producid` int(11) NOT NULL,
  `proname` varchar(100) NOT NULL,
  `prodes` varchar(500) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product1`
--

INSERT INTO `product1` (`producid`, `proname`, `prodes`, `picture`, `status`, `login_id`, `product_id`) VALUES
(4, 'kitchen galley', 'A galley kitchen is a long, narrow kitchen that has base cabinets, wall cabinets, counters, or other services located on one or both sides of a central walkway. The counter tops can be interspersed with appliances like fridges, sinks, cabinetry and other functional items.', 'galley.jpg', 1, 3, 19),
(5, 'kitchen l-shaped', 'The L-shaped kitchen layout is a standard design for home kitchens. ... The L-shaped kitchen is not a dated style or difficult to match to any decor. The shape simply refers to the floor plan layout and does not constitute any additional restrictions or requirements passed that.', 'lshaped.jpg', 1, 3, 19),
(6, 'Master bedroom', 'The features found in this room are quite exquisite and inviting. They vary from Jacuzzis, the room usually-suit, built-in wall interior designs and comfortable beddings. Furniture(s) and other items in a bedroom vary greatly, depending on taste and local tradition. For instance, a master bedroom may include a bed of a specific size (double, king or queen-sized) one or more dressers (or a wardrobe armoire) cushions, and the like.', 'master.jpg', 1, 3, 18),
(7, 'Traditional living room style', 'Traditional design is a style that is steeped in elegance and sophistication. The look in traditional rooms is built on concepts from back in the 18th and 19th centuries. The furnishings in this style are finely crafted and eloquent finished wood tone pieces. Adornments should be sophisticated and fancy.\r\n\r\nFurnishings should be finely crafted, and have a element of elaborate woodwork. Harsh and sharp angles should be avoided.', 'tradliving.jpg', 1, 3, 21),
(8, 'children\'s bedroom', 'The theme or concept for children\'s bedroom can be both playful and functional. The room can be the place for the children to sleep, rest, play and this can be also useful or functional such as studying or the place for parents to do nursery in that room.', 'children.jpg', 1, 3, 18),
(9, 'Guest room', 'The best guest rooms are uncluttered, comfortable and feel a little like home. But it is also a place to put your own personal touch and make your guest feel like they\'re staying somewhere that\'s well thought out and intentional.', 'guest.jpg', 1, 3, 18),
(10, 'Contemporary designs', 'Contemporary designs are often mistaken with modern designs. Contemporary is not what you think it is as being modern or such. These are designs created presently, occurring on this time and will still undergo changes. Hence, contemporary is ever-changing and flexible. These can be a combination of all types of traditional, modern or rustic designs.', '2b-Contemporary-Living-Room.jpg', 1, 3, 21),
(11, 'West Coast Contemporary', 'West Coast Contemporary is a mixture of several designs like classic and modern. They often mirror classic cabin designs with a twist of modern design. These designs used West Coast local materials, which is where the name of the design itself is inspired from.', '3a-West-Coast-Contemporary.jpg', 1, 3, 21),
(12, 'Open shelving', 'The open shelving design is quickly becoming the most popular, especially for those who are looking for a more less obtrusive setup, conserving space and providing an open visual element. Usually a central frame holds several shelves, and often provides a mounting bracket for the television itself.', 'openshelvingtv-870x870.jpg', 1, 3, 20),
(13, 'Console tv units', 'With a singular, holistic shape, the console design incorporates useful shelving and abundant surface area into a concise piece of furniture. Most models have closed shelving and a rectangular structure.\r\n\r\n', 'consoletv-870x870.jpg', 1, 3, 20),
(14, 'Stand With Audio Towers', 'The TV stand with audio towers is a modular form that mimics most of the functionality and presentation of a full entertainment center, with a pair of tall structured shelves flanking the central stand and television itself. These allow for the placement of speakers and any other supplemental equipment.', 'speakertowers-870x609.jpg', 1, 3, 20),
(15, 'pallet racking', 'Pallets: the most common and essential component of logistical stock storage and movement. Made of wood, metal or plastic,\r\n\r\nAnything which is delivered and stored in boxes and requires inventory logging is a prime candidate for pallet racking.\r\n\r\nThe most important considerations with pallet racking are access/movement, weight, stability and space. Weight limits must be strictly adhered to and all pallet racking must be inspected and maintained regularly to make sure that it is stable enough n', 'pallet.jpg', 1, 3, 22);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product` varchar(100) NOT NULL,
  `descr` varchar(500) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product`, `descr`, `picture`, `category_id`, `status`, `login_id`) VALUES
(18, 'Bedroom design', 'Even though the bedroom is a private space that will be seen by far fewer people than your living ro', 'bedrom.jpg', 34, '1', 3),
(19, 'Kitchen designs', 'Several types of kitchen designs are available.', 'kitchen.jpg', 53, '1', 3),
(20, 'Tv Units', 'Variety of tv units designs can be explored', 'tv units.jpg', 60, '1', 3),
(21, 'Living Room', 'Different sets of designs are availble.', 'livingrm.jpg', 33, '1', 3),
(22, 'Store room', 'The storage room is a place (for example, like a room, closet, in-door or out-door container where temporarily the businesses partners or individuals can store their belongings. The leasers/renters are offered storages of a different size and specifications (for example, heated or unheated).', 'storerm.jpg', 39, '1', 3);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `reg_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`reg_id`, `name`, `email`, `phone`, `login_id`) VALUES
(21, 'annuu', 'asha@gmail.com', '9876543210', 176),
(22, 'appumon', 'appu1@gmail.com', '8945623102', 198),
(24, 'sandeep ', 'sandeep@gmail.com', '8956234101', 205),
(25, 'krithi krishna', 'kkrithi97@gmail.com', '8078919098', 214),
(26, 'Rema Krishna', 'rema@gmail.com', '9446518098', 220);

-- --------------------------------------------------------

--
-- Table structure for table `servicetbl`
--

CREATE TABLE `servicetbl` (
  `serviceid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `service` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `productname` varchar(100) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `servicetbl`
--

INSERT INTO `servicetbl` (`serviceid`, `name`, `service`, `phone`, `email`, `productname`, `picture`, `status`) VALUES
(7, 'sandeep ks ', 'carpentar', '8956234100', 'sandeep@gmail.com', 'chair', 's3.png', 2),
(8, 'sandeep ks ', 'carpenter', '8956234100', 'sandeep@gmail.com', 'bedroom door', 'a1.jpg', 0),
(9, 'sandeep ks ', 'carpenter', '8956234100', 'sandeep@gmail.com', 'bedroom door', 'b1.jpg', 0),
(10, 'sandeep ks ', 'carpenter', '8956234100', 'sandeep@gmail.com', 'kitchen door', 'b2.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `servicetype`
--

CREATE TABLE `servicetype` (
  `serv_id` int(11) NOT NULL,
  `servicetype` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `servicetype`
--

INSERT INTO `servicetype` (`serv_id`, `servicetype`, `status`) VALUES
(1, 'carpenter', 1),
(2, 'designer', 1),
(3, 'Electrician', 1),
(4, 'Plumber', 1),
(5, 'Painter', 1);

-- --------------------------------------------------------

--
-- Table structure for table `staffdetails`
--

CREATE TABLE `staffdetails` (
  `staffid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `login_id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffdetails`
--

INSERT INTO `staffdetails` (`staffid`, `name`, `dob`, `gender`, `address`, `state`, `city`, `phone`, `email`, `password`, `login_id`, `status`) VALUES
(15, 'krithi', '2020-02-11', 'Female', 'chengannur', 'Kerala', 'Chengannur', '7896321420', 'kkrithi97@gmail.com', 'krithi12', 194, 1),
(19, 'vipin venu', '2020-03-19', 'Male', 'kochuthekkekkara', 'Kerala', 'chengannur', '7736612514', 'appuvipin123@gmail.com', 'appu123', 201, 1),
(21, 'litty', '2020-03-11', 'Female', 'poovathinkal', 'Kerala', 'kottayam', '9874563210', 'litty4ever@gmail.com', 'litty123', 203, 1),
(22, 'minnu raj', '1997-08-05', 'Female', 'chaithanya', 'Kerala', 'pathanamthitta', '7894561230', 'minnuraj@mca.ajce.in', 'minnu123', 204, 1),
(30, 'rema devi', '1964-06-30', 'Female', 'valavanattu', 'kerala', 'vaipur', '7896541230', 'krishnakrithi97@gmail.com', 'krishna123', 219, 1),
(31, 'Kripa Krishna', '1986-11-21', 'Female', 'Channathil', 'kerala', 'Chengannur', '9207091581', 'krishkripa1986@gmail.com', 'kripa123', 221, 1),
(32, 'Kripa Krishna', '1986-11-21', 'Female', 'Channathil', 'kerala', 'Chengannur', '9207091581', 'krishkripa1986@gmail.com', 'kripa123', 222, 1);

-- --------------------------------------------------------

--
-- Table structure for table `subcat`
--

CREATE TABLE `subcat` (
  `subcatid` int(11) NOT NULL,
  `subcatname` varchar(100) NOT NULL,
  `category_id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcat`
--

INSERT INTO `subcat` (`subcatid`, `subcatname`, `category_id`, `status`) VALUES
(42, 'Living Storage', 33, 1),
(43, 'Living chairs', 33, 1),
(44, 'living room', 33, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblleaves`
--

CREATE TABLE `tblleaves` (
  `leaveid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `LeaveType` varchar(110) NOT NULL,
  `FromDate` varchar(120) NOT NULL,
  `session` varchar(100) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `login_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblleaves`
--

INSERT INTO `tblleaves` (`leaveid`, `email`, `LeaveType`, `FromDate`, `session`, `Description`, `login_id`, `status`) VALUES
(4, 'litty4ever@gmail.com', 'Casual Leave', '2020-03-20', 'Fn', 'Headache', 203, 0),
(6, 'litty4ever@gmail.com', 'Restricted Holiday', '2020-03-07', 'Full day', 'Body Pain', 203, 2),
(17, 'appuvipin123@gmail.c', 'Casual Leave', '2020-05-05', 'Fd', 'personal reason', 201, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblleavetype`
--

CREATE TABLE `tblleavetype` (
  `leaveid` int(11) NOT NULL,
  `leavetype` varchar(200) DEFAULT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblleavetype`
--

INSERT INTO `tblleavetype` (`leaveid`, `leavetype`, `status`) VALUES
(1, 'Casual Leave', 1),
(2, 'Medical Leave', 1),
(3, 'Restricted Holiday', 0),
(4, 'Restricted Holiday', 1);

-- --------------------------------------------------------

--
-- Table structure for table `worktbl`
--

CREATE TABLE `worktbl` (
  `workid` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `dow` varchar(100) NOT NULL,
  `work` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `doww` varchar(100) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `worktbl`
--

INSERT INTO `worktbl` (`workid`, `login_id`, `dow`, `work`, `location`, `district`, `address`, `city`, `doww`, `picture`, `status`) VALUES
(1, 0, '2020-02-01', 'design', 'chengannur', '', '', '', '', '', 1),
(2, 0, '2020-02-28', 'paint', 'chengannur', '', '', '', '', '', 1),
(3, 0, '2020-02-29', 'design', 'Kottayam', '', '', '', '', '', 1),
(4, 0, '2020-02-29', 'design', 'kottayam', '', '', '', '', '', 1),
(5, 0, '2020-02-29', 'design', 'kollam', '', '', '', '', '', 1),
(6, 0, '2020-02-29', 'paint', 'kottarakkara', '', '', '', '', '', 1),
(7, 16, '2020-02-29', 'design', 'alappuzha', '', '', '', '', '', 1),
(8, 0, '2020-02-28', 'paint', 'kollam', '', '', '', '', '', 1),
(9, 17, '2020-02-29', 'paint', 'alappuzha', '', '', '', '', '', 1),
(10, 196, '2020-02-29', 'design', 'kollam', '', '', '', '', '', 1),
(11, 201, '2020-03-25', 'design', 'angadical', 'ala', 'puthenpurayil', 'chengannur', '2020-03-19', 'a1.jpg', 0),
(23, 196, '2020-03-05', 'Painting', 'kunnam', 'Alappuzha', 'mundakkavu', 'Mavelikkara', '2020-03-14', 'a4.jpg', 1),
(27, 203, '2020-03-04', 'Designing', 'mnbv', 'pathanamthitta', 'kjghjgjd', 'sdafsg', '2020-03-19', 'a2.jpg', 0),
(28, 203, '2020-05-05', 'Designing', 'angadical', 'Alappuzha', 'puthenpurayil', 'chengannur', '2020-05-09', 'b1.jpg', 1),
(30, 204, '2020-05-08', 'Designing', 'edathva', 'Alappuzha', 'kunnel', 'kuttanad', '2020-05-10', 'Screenshot (10).png', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contactid`);

--
-- Indexes for table `estimate`
--
ALTER TABLE `estimate`
  ADD PRIMARY KEY (`estid`);

--
-- Indexes for table `jobasstbl`
--
ALTER TABLE `jobasstbl`
  ADD PRIMARY KEY (`assid`);

--
-- Indexes for table `jobtbl`
--
ALTER TABLE `jobtbl`
  ADD PRIMARY KEY (`jobid`);

--
-- Indexes for table `jobuser`
--
ALTER TABLE `jobuser`
  ADD PRIMARY KEY (`jobuserid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `orderconf`
--
ALTER TABLE `orderconf`
  ADD PRIMARY KEY (`confid`);

--
-- Indexes for table `packtbl`
--
ALTER TABLE `packtbl`
  ADD PRIMARY KEY (`packid`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`paymid`);

--
-- Indexes for table `pendingtbl`
--
ALTER TABLE `pendingtbl`
  ADD PRIMARY KEY (`pendid`);

--
-- Indexes for table `product1`
--
ALTER TABLE `product1`
  ADD PRIMARY KEY (`producid`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`reg_id`);

--
-- Indexes for table `servicetbl`
--
ALTER TABLE `servicetbl`
  ADD PRIMARY KEY (`serviceid`);

--
-- Indexes for table `servicetype`
--
ALTER TABLE `servicetype`
  ADD PRIMARY KEY (`serv_id`);

--
-- Indexes for table `staffdetails`
--
ALTER TABLE `staffdetails`
  ADD PRIMARY KEY (`staffid`);

--
-- Indexes for table `subcat`
--
ALTER TABLE `subcat`
  ADD PRIMARY KEY (`subcatid`);

--
-- Indexes for table `tblleaves`
--
ALTER TABLE `tblleaves`
  ADD PRIMARY KEY (`leaveid`);

--
-- Indexes for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  ADD PRIMARY KEY (`leaveid`);

--
-- Indexes for table `worktbl`
--
ALTER TABLE `worktbl`
  ADD PRIMARY KEY (`workid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contactid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `estimate`
--
ALTER TABLE `estimate`
  MODIFY `estid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `jobasstbl`
--
ALTER TABLE `jobasstbl`
  MODIFY `assid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `jobtbl`
--
ALTER TABLE `jobtbl`
  MODIFY `jobid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `jobuser`
--
ALTER TABLE `jobuser`
  MODIFY `jobuserid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=223;

--
-- AUTO_INCREMENT for table `orderconf`
--
ALTER TABLE `orderconf`
  MODIFY `confid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `packtbl`
--
ALTER TABLE `packtbl`
  MODIFY `packid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `paymid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `pendingtbl`
--
ALTER TABLE `pendingtbl`
  MODIFY `pendid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product1`
--
ALTER TABLE `product1`
  MODIFY `producid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `servicetbl`
--
ALTER TABLE `servicetbl`
  MODIFY `serviceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `servicetype`
--
ALTER TABLE `servicetype`
  MODIFY `serv_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `staffdetails`
--
ALTER TABLE `staffdetails`
  MODIFY `staffid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `subcat`
--
ALTER TABLE `subcat`
  MODIFY `subcatid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `tblleaves`
--
ALTER TABLE `tblleaves`
  MODIFY `leaveid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  MODIFY `leaveid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `worktbl`
--
ALTER TABLE `worktbl`
  MODIFY `workid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
